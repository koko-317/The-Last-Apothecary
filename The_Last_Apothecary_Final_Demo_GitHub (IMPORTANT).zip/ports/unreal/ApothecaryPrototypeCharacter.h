#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "ApothecaryPrototypeCharacter.generated.h"

class UCameraComponent;
class UStaticMeshComponent;

UCLASS()
class AApothecaryPrototypeCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    AApothecaryPrototypeCharacter();
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void Tick(float DeltaSeconds) override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Apothecary")
    TObjectPtr<UCameraComponent> SideCamera;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Apothecary")
    TObjectPtr<UStaticMeshComponent> PlaceholderVisual;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Apothecary|Movement")
    float RunSpeed = 620.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Apothecary|Movement")
    float DashSpeed = 1300.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Apothecary|Movement")
    bool bDashUnlocked = false;

    UFUNCTION(BlueprintCallable, Category="Apothecary")
    void SetDashUnlocked(bool bUnlocked) { bDashUnlocked = bUnlocked; }

    UFUNCTION(BlueprintCallable, Category="Apothecary")
    void SetPausedFromWidget(bool bShouldPause);

protected:
    void MoveRight(float Value);
    void BeginJump();
    void EndJump();
    void Strike();
    void Dash();
    void Interact();
    void ToggleMap();
    void TogglePause();

    float Facing = 1.0f;
    float DashRemaining = 0.0f;
    bool bVialUnlocked = false;
    bool bMapVisible = false;
};
