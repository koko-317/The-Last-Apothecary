#include "ApothecaryPrototypeCharacter.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "UObject/ConstructorHelpers.h"

AApothecaryPrototypeCharacter::AApothecaryPrototypeCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
    GetCapsuleComponent()->InitCapsuleSize(28.0f, 48.0f);
    GetCharacterMovement()->GravityScale = 2.2f;
    GetCharacterMovement()->JumpZVelocity = 620.0f;
    GetCharacterMovement()->AirControl = 0.75f;
    GetCharacterMovement()->bOrientRotationToMovement = false;
    GetCharacterMovement()->bConstrainToPlane = true;
    GetCharacterMovement()->SetPlaneConstraintNormal(FVector(0.0f, 1.0f, 0.0f));
    bUseControllerRotationYaw = false;

    PlaceholderVisual = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PlaceholderVisual"));
    PlaceholderVisual->SetupAttachment(GetCapsuleComponent());
    PlaceholderVisual->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (CubeMesh.Succeeded()) PlaceholderVisual->SetStaticMesh(CubeMesh.Object);
    PlaceholderVisual->SetRelativeLocation(FVector(0.0f, 0.0f, -5.0f));
    PlaceholderVisual->SetRelativeScale3D(FVector(0.38f, 0.22f, 0.78f));
    PlaceholderVisual->SetVectorParameterValueOnMaterials(TEXT("Color"), FVector(0.65f, 0.72f, 0.78f));

    SideCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("SideCamera"));
    SideCamera->SetupAttachment(GetRootComponent());
    SideCamera->SetRelativeLocation(FVector(0.0f, -1300.0f, 0.0f));
    SideCamera->SetRelativeRotation(FRotator(0.0f, 90.0f, 0.0f));
    SideCamera->ProjectionMode = ECameraProjectionMode::Orthographic;
    SideCamera->OrthoWidth = 1600.0f;
}

void AApothecaryPrototypeCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);
    check(PlayerInputComponent);
    PlayerInputComponent->BindAxis(TEXT("MoveRight"), this, &AApothecaryPrototypeCharacter::MoveRight);
    PlayerInputComponent->BindAction(TEXT("Jump"), IE_Pressed, this, &AApothecaryPrototypeCharacter::BeginJump);
    PlayerInputComponent->BindAction(TEXT("Jump"), IE_Released, this, &AApothecaryPrototypeCharacter::EndJump);
    PlayerInputComponent->BindAction(TEXT("Strike"), IE_Pressed, this, &AApothecaryPrototypeCharacter::Strike);
    PlayerInputComponent->BindAction(TEXT("Dash"), IE_Pressed, this, &AApothecaryPrototypeCharacter::Dash);
    PlayerInputComponent->BindAction(TEXT("Interact"), IE_Pressed, this, &AApothecaryPrototypeCharacter::Interact);
    PlayerInputComponent->BindAction(TEXT("Map"), IE_Pressed, this, &AApothecaryPrototypeCharacter::ToggleMap);
    PlayerInputComponent->BindAction(TEXT("Pause"), IE_Pressed, this, &AApothecaryPrototypeCharacter::TogglePause);
}

void AApothecaryPrototypeCharacter::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    if (DashRemaining > 0.0f)
    {
        DashRemaining -= DeltaSeconds;
        GetCharacterMovement()->Velocity.X = Facing * DashSpeed;
        GetCharacterMovement()->Velocity.Z = 0.0f;
        if (DashRemaining <= 0.0f) GetCharacterMovement()->SetMovementMode(MOVE_Walking);
    }
    if (SideCamera) SideCamera->OrthoWidth = FMath::FInterpTo(SideCamera->OrthoWidth, 1600.0f, DeltaSeconds, 3.0f);
}

void AApothecaryPrototypeCharacter::MoveRight(float Value)
{
    if (FMath::Abs(Value) < KINDA_SMALL_NUMBER) return;
    Facing = FMath::Sign(Value);
    AddMovementInput(FVector(1.0f, 0.0f, 0.0f), Value);
    if (PlaceholderVisual) PlaceholderVisual->SetRelativeRotation(FRotator(0.0f, Facing > 0 ? 0.0f : 180.0f, 0.0f));
}

void AApothecaryPrototypeCharacter::BeginJump() { Jump(); }
void AApothecaryPrototypeCharacter::EndJump() { StopJumping(); }
void AApothecaryPrototypeCharacter::Strike() { UE_LOG(LogTemp, Log, TEXT("Apothecary strike placeholder: connect a forward hitbox in Blueprint.")); }
void AApothecaryPrototypeCharacter::Dash()
{
    if (!bDashUnlocked || DashRemaining > 0.0f) return;
    DashRemaining = 0.18f;
    GetCharacterMovement()->SetMovementMode(MOVE_Flying);
    GetCharacterMovement()->Velocity = FVector(Facing * DashSpeed, 0.0f, 0.0f);
}
void AApothecaryPrototypeCharacter::Interact() { UE_LOG(LogTemp, Log, TEXT("Interact placeholder: call checkpoint or lever Blueprint interface.")); }
void AApothecaryPrototypeCharacter::ToggleMap() { bMapVisible = !bMapVisible; UE_LOG(LogTemp, Log, TEXT("Map toggled: %s"), bMapVisible ? TEXT("visible") : TEXT("hidden")); }
void AApothecaryPrototypeCharacter::TogglePause()
{
    APlayerController* PC = Cast<APlayerController>(GetController());
    if (!PC) return;
    SetPausedFromWidget(!PC->IsPaused());
}
void AApothecaryPrototypeCharacter::SetPausedFromWidget(bool bShouldPause)
{
    APlayerController* PC = Cast<APlayerController>(GetController());
    if (!PC) return;
    PC->SetPause(bShouldPause);
    PC->SetShowMouseCursor(bShouldPause);
    if (bShouldPause)
    {
        FInputModeGameAndUI InputMode;
        PC->SetInputMode(InputMode);
    }
    else
    {
        FInputModeGameOnly InputMode;
        PC->SetInputMode(InputMode);
    }
}
