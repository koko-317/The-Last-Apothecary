# Unreal Engine C++ starter (source-only)

This directory is a native **character/controller starter**, not a completed Unreal conversion of every browser room and mechanic. The full playable game remains `../../index.html`. These C++ files are not compiled here, so validate them against your exact Unreal Engine version before use.

## Create a project and add code

1. Create a new Unreal Engine C++ project (blank or side-scroller template) named `TheLastApothecary`.
2. Add `ApothecaryPrototypeCharacter.h` and `.cpp` to the project's game module source folder. Merge the dependency list in `TheLastApothecary.Build.cs` into the generated module's `.Build.cs` rather than blindly replacing engine-version-specific generated settings.
3. Merge the mappings in `DefaultInput.ini` into the project's `Config/DefaultInput.ini`. If using Enhanced Input only, create equivalent Input Actions and mappings instead of using the legacy bindings here.
4. Compile from the Unreal editor/IDE. Set the default pawn/game mode to `AApothecaryPrototypeCharacter` in project settings or a GameMode Blueprint.
5. Put the side-scrolling play plane on X/Z with platforms and walls built from Engine Basic Shapes cubes. Keep static geometry at Y=0. The character constrains movement to the plane, and its camera uses orthographic projection.

## Placeholder level layout

Create five adjacent named sections with floor blocks and visible text labels: Sealed Chapel, Plague Street, Cistern, Root Hall, and Ossuary. Use cubes scaled as platforms; for one-way planks, use a Blueprint Actor with a thin Box Collision and one-way collision responses. Add simple colored cubes for enemies/pickups until replacing them with original art. No third-party asset pack is needed.

## HUD, progression, and pause menu

Create a UMG Widget Blueprint with readable high-contrast text and buttons `Resume`, `Map`, and `Back to Main Menu`. Bind Resume to `SetPausedFromWidget(false)`. Bind Map to your map widget/overlay. Bind Back to Main Menu to save checkpoint and progression variables, remove the pause widget, and `Open Level` to the title/main-menu map. Preserve save state separately from transient UI state. Add Blueprint interfaces/events for `Strike` (hitbox), `Interact` (checkpoint/lever), vial throwing, health, reagent, and exit transitions; those hooks are left as integration points in this starter source.

## Limitations

The C++ starter provides 2D-plane movement, jump, dash gating, camera, and input hooks. It does not yet implement the full HTML game's nine-room level data, combat, vial physics, level gates, save system, or actual UMG screens; those require the level/Blueprint work outlined above. It is intentionally labeled as source-only instead of claiming an untested native port compiles or has feature parity.
