using System.Collections.Generic;
using UnityEngine;

// Source-only Unity vertical slice. Attach to an empty GameObject in a new 2D scene.
// All art is generated from a 1x1 white sprite; no external assets are required.
public sealed class ApothecaryNativePrototype : MonoBehaviour
{
    private const int GroundLayer = 8;
    private sealed class EnemyData { public GameObject gameObject; public float origin, direction = 1f, health = 3f; }
    private readonly List<EnemyData> enemies = new List<EnemyData>();
    private readonly List<Transform> stations = new List<Transform>();
    private readonly List<Transform> pickups = new List<Transform>();
    private readonly List<string> pickupKinds = new List<string>();
    private Sprite pixel;
    private GameObject player;
    private Rigidbody2D rb;
    private SpriteRenderer playerRenderer;
    private Camera cam;
    private bool title = true, paused, showMap, gateOpen;
    private bool dashUnlocked, vialUnlocked;
    private float hp = 5, maxHp = 5, reagent, dashTime, attackTime, invulnerable, coyote;
    private float checkpointX = 3f, checkpointY = -1.5f;
    private float facing = 1f;
    private string currentArea = "Sealed Chapel";
    private string hint = "Explore the ruins. E interacts with stations and the Root Hall lever.";
    private Transform lever;
    private GameObject chapelGate;
    private static readonly string[] Areas = { "Sealed Chapel", "Plague Street", "Cistern", "Root Hall", "Ossuary" };

    private void Awake()
    {
        Application.targetFrameRate = 60;
        Texture2D texture = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        texture.SetPixel(0, 0, Color.white); texture.Apply(); texture.filterMode = FilterMode.Point;
        pixel = Sprite.Create(texture, new Rect(0, 0, 1, 1), new Vector2(.5f, .5f), 1);
        BuildCamera(); BuildLevel(); BuildPlayer();
        checkpointX = PlayerPrefs.GetFloat("LAA_CP_X", 3f);
        checkpointY = PlayerPrefs.GetFloat("LAA_CP_Y", -1.5f);
        dashUnlocked = PlayerPrefs.GetInt("LAA_DASH", 0) == 1;
        vialUnlocked = PlayerPrefs.GetInt("LAA_VIAL", 0) == 1;
        gateOpen = PlayerPrefs.GetInt("LAA_GATE", 0) == 1;
        reagent = PlayerPrefs.GetInt("LAA_REAGENT", 0);
        if (chapelGate) chapelGate.SetActive(!gateOpen);
    }

    private void BuildCamera()
    {
        cam = Camera.main;
        if (!cam) { var go = new GameObject("Main Camera"); go.tag = "MainCamera"; cam = go.AddComponent<Camera>(); }
        cam.orthographic = true; cam.orthographicSize = 5.2f; cam.backgroundColor = new Color(.025f, .035f, .05f);
        cam.transform.position = new Vector3(3, 0, -10);
    }

    private GameObject Block(string name, Vector2 pos, Vector2 size, Color color, bool solid = true, bool oneWay = false)
    {
        var go = new GameObject(name); go.transform.position = pos; go.transform.localScale = new Vector3(size.x, size.y, 1);
        var sr = go.AddComponent<SpriteRenderer>(); sr.sprite = pixel; sr.color = color; sr.sortingOrder = 0;
        if (solid) {
            go.layer = GroundLayer;
            var box = go.AddComponent<BoxCollider2D>();
            if (oneWay) { box.usedByEffector = true; var eff = go.AddComponent<PlatformEffector2D>(); eff.useOneWay = true; eff.surfaceArc = 180; }
        }
        return go;
    }

    private Transform Marker(string name, Vector2 pos, Color color, float scale = .5f)
    {
        var go = Block(name, pos, new Vector2(scale, scale), color, false); return go.transform;
    }

    private void Label(string text, Vector2 pos, int size = 36)
    {
        var go = new GameObject("Label - " + text); go.transform.position = pos;
        var tm = go.AddComponent<TextMesh>(); tm.text = text; tm.fontSize = size; tm.characterSize = .14f;
        tm.anchor = TextAnchor.MiddleCenter; tm.alignment = TextAlignment.Center; tm.color = new Color(.9f, .78f, .5f);
        var mr = go.GetComponent<MeshRenderer>(); mr.sortingOrder = 5;
    }

    private void BuildLevel()
    {
        Color stone = new Color(.12f, .16f, .2f), plank = new Color(.42f, .28f, .16f);
        // Connected five-area side-scrolling strip. Gaps/platforms are intentionally simple placeholders.
        // Segmented floor leaves a real gap in the Cistern.
        Block("Chapel floor", new Vector2(9, -3), new Vector2(18, 1), stone);
        Block("Plague Street floor", new Vector2(29, -3), new Vector2(22, 1), stone);
        Block("Cistern west ledge", new Vector2(42, -3), new Vector2(4, 1), stone);
        Block("Cistern east ledge", new Vector2(51, -3), new Vector2(6, 1), stone);
        Block("Root Hall floor", new Vector2(72, -3), new Vector2(36, 1), stone);
        Block("Ossuary floor", new Vector2(96, -3), new Vector2(14, 1), stone);
        // Chapel first step remains solid; higher stairs and Plague Street stairs are one-way.
        Block("Chapel first solid platform", new Vector2(8, -1.1f), new Vector2(3, .35f), plank);
        Block("Chapel one-way step 2", new Vector2(11, -.2f), new Vector2(3, .22f), plank, true, true);
        Block("Chapel one-way step 3", new Vector2(14, .7f), new Vector2(3, .22f), plank, true, true);
        Block("Plague Street stair 1 [30,13,3,1,3]", new Vector2(30.5f, -1.25f), new Vector2(3, .22f), plank, true, true);
        Block("Plague Street stair 2", new Vector2(34, -.25f), new Vector2(3, .22f), plank, true, true);
        Block("Plague Street stair 3", new Vector2(37.2f, .65f), new Vector2(3, .22f), plank, true, true);
        Block("Ossuary stair", new Vector2(88, -1.2f), new Vector2(3, .22f), plank, true, true);
        Block("Ossuary stair high", new Vector2(92, -.25f), new Vector2(3, .22f), plank, true, true);
        chapelGate = Block("Sealed Chapel high gate", new Vector2(15.5f, 1.35f), new Vector2(.4f, 3), new Color(.45f, .12f, .17f));
        Label("SEALED CHAPEL", new Vector2(7, 3.5f)); Label("PLAGUE STREET", new Vector2(29, 3.5f));
        Label("CISTERN", new Vector2(46, 3.5f)); Label("ROOT HALL", new Vector2(69, 3.5f)); Label("OSSUARY", new Vector2(94, 3.5f));
        stations.Add(Marker("Chapel checkpoint", new Vector2(4, -2.2f), new Color(.9f, .66f, .26f), .55f));
        stations.Add(Marker("Street checkpoint", new Vector2(25, -2.2f), new Color(.9f, .66f, .26f), .55f));
        stations.Add(Marker("Root checkpoint", new Vector2(66, -2.2f), new Color(.9f, .66f, .26f), .55f));
        lever = Marker("Root Hall gate lever", new Vector2(71, -2.2f), new Color(.75f, .28f, .25f), .65f);
        AddPickup("DASH UPGRADE", new Vector2(36, -1.8f), new Color(.95f, .68f, .2f));
        AddPickup("VIAL UPGRADE", new Vector2(53, -1.8f), new Color(.45f, .8f, .45f));
        AddPickup("HEALTH MASK", new Vector2(89, -1.8f), new Color(.86f, .84f, .75f));
        AddEnemy(new Vector2(27, -1.9f)); AddEnemy(new Vector2(57, -1.9f)); AddEnemy(new Vector2(98, -1.9f));
    }

    private void AddPickup(string name, Vector2 pos, Color color)
    {
        var tr = Marker(name, pos, color, .65f); pickups.Add(tr); pickupKinds.Add(name);
    }

    private void AddEnemy(Vector2 pos)
    {
        var go = Block("Plague-touched enemy", pos, new Vector2(.7f, 1.2f), new Color(.38f, .48f, .3f));
        go.layer = 0; // enemies must not count as ground for the player's ground ray
        enemies.Add(new EnemyData { gameObject = go, origin = pos.x });
    }

    private void BuildPlayer()
    {
        player = Block("Player - Lantern Keeper", new Vector2(3, -1.65f), new Vector2(.65f, 1.35f), new Color(.7f, .76f, .8f), false);
        playerRenderer = player.GetComponent<SpriteRenderer>();
        var col = player.AddComponent<BoxCollider2D>(); col.size = Vector2.one; // visual scale defines the collider's world dimensions
        rb = player.AddComponent<Rigidbody2D>(); rb.freezeRotation = true; rb.gravityScale = 3.4f; rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
    }

    private bool Grounded() => Physics2D.Raycast(player.transform.position, Vector2.down, .78f, 1 << GroundLayer);

    private void Update()
    {
        if (title) return;
        if (Input.GetKeyDown(KeyCode.Escape)) {
            if (showMap) { showMap = false; return; }
            paused = !paused; return;
        }
        if (Input.GetKeyDown(KeyCode.M) && !paused) { showMap = !showMap; return; }
        if (paused || showMap) return;
        reagent = Mathf.Max(reagent, PlayerPrefs.GetInt("LAA_REAGENT", 0));
        foreach (var enemy in enemies) {
            if (enemy == null || enemy.gameObject == null) continue;
            enemy.gameObject.transform.position += Vector3.right * enemy.direction * Time.deltaTime * 1.1f;
            if (Mathf.Abs(enemy.gameObject.transform.position.x - enemy.origin) > 2.2f) enemy.direction *= -1f;
            if (invulnerable <= 0 && Mathf.Abs(enemy.gameObject.transform.position.x - player.transform.position.x) < .65f && Mathf.Abs(enemy.gameObject.transform.position.y - player.transform.position.y) < 1.2f) {
                hp -= 1; invulnerable = .9f; if (hp <= 0) Respawn();
            }
        }
        float dir = (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow) ? 1 : 0) - (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow) ? 1 : 0);
        if (dir != 0) facing = Mathf.Sign(dir);
        if (dashTime > 0) { dashTime -= Time.deltaTime; rb.velocity = new Vector2(facing * 15f, 0); }
        else rb.velocity = new Vector2(dir * 7.5f, rb.velocity.y);
        bool grounded = Grounded(); if (grounded) coyote = .12f; else coyote -= Time.deltaTime;
        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow)) && coyote > 0) { rb.velocity = new Vector2(rb.velocity.x, 11f); coyote = 0; }
        if ((Input.GetKeyUp(KeyCode.Space) || Input.GetKeyUp(KeyCode.UpArrow)) && rb.velocity.y > 0) rb.velocity = new Vector2(rb.velocity.x, rb.velocity.y * .48f);
        if (dashUnlocked && (Input.GetKeyDown(KeyCode.K) || Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift)) && dashTime <= 0) dashTime = .18f;
        if (Input.GetKeyDown(KeyCode.J)) { attackTime = .15f; foreach (var e in enemies) if (e != null && e.gameObject != null && Mathf.Abs(e.gameObject.transform.position.x - player.transform.position.x) < 1.5f && Mathf.Abs(e.gameObject.transform.position.y - player.transform.position.y) < 1.7f && Mathf.Sign(e.gameObject.transform.position.x - player.transform.position.x) == facing) DamageEnemy(e, 2); }
        if (attackTime > 0) attackTime -= Time.deltaTime;
        if (Input.GetKeyDown(KeyCode.Q) && grounded && hp < maxHp && reagent >= 3) { hp = Mathf.Min(maxHp, hp + 1); reagent -= 3; PlayerPrefs.SetInt("LAA_REAGENT", Mathf.FloorToInt(reagent)); PlayerPrefs.Save(); }
        if (vialUnlocked && Input.GetKeyDown(KeyCode.L) && reagent > 0) { reagent--; PlayerPrefs.SetInt("LAA_REAGENT", Mathf.FloorToInt(reagent)); PlayerPrefs.Save(); foreach (var e in enemies) if (e != null && e.gameObject != null && Mathf.Abs(e.gameObject.transform.position.x - player.transform.position.x) < 5f) DamageEnemy(e, 3); hint = "The vial shatters in a green cloud."; }
        if (Input.GetKeyDown(KeyCode.E)) Interact();
        CollectPickups(); UpdateArea();
        if (player.transform.position.y < -7) Respawn();
        if (cam) { var pos = cam.transform.position; pos.x = Mathf.Lerp(pos.x, player.transform.position.x, Time.deltaTime * 5f); cam.transform.position = pos; }
        if (invulnerable > 0) invulnerable -= Time.deltaTime;
    }

    private void DamageEnemy(EnemyData enemy, int amount)
    {
        enemy.health -= amount;
        if (enemy.health <= 0 && enemy.gameObject != null) {
            reagent = Mathf.Min(9, reagent + 1); PlayerPrefs.SetInt("LAA_REAGENT", Mathf.FloorToInt(reagent)); PlayerPrefs.Save();
            Destroy(enemy.gameObject); enemy.gameObject = null;
        }
    }

    private void Interact()
    {
        foreach (var s in stations) if (s && Vector2.Distance(s.position, player.transform.position) < 1.5f) {
            checkpointX = s.position.x; checkpointY = s.position.y + .8f; hp = maxHp;
            PlayerPrefs.SetFloat("LAA_CP_X", checkpointX); PlayerPrefs.SetFloat("LAA_CP_Y", checkpointY); PlayerPrefs.Save();
            hint = "Checkpoint secured. Wounds treated; progress saved."; return;
        }
        if (lever && Vector2.Distance(lever.position, player.transform.position) < 1.8f) {
            gateOpen = true; if (chapelGate) chapelGate.SetActive(false); PlayerPrefs.SetInt("LAA_GATE", 1); PlayerPrefs.Save();
            hint = "The Root Hall lever opens the high gate in the Sealed Chapel.";
        }
    }

    private void CollectPickups()
    {
        for (int i = pickups.Count - 1; i >= 0; --i) {
            var it = pickups[i]; if (!it || Vector2.Distance(it.position, player.transform.position) > .8f) continue;
            string kind = pickupKinds[i];
            if (kind.StartsWith("DASH")) { dashUnlocked = true; PlayerPrefs.SetInt("LAA_DASH", 1); hint = "DASH unlocked: K or Shift."; }
            else if (kind.StartsWith("VIAL")) { vialUnlocked = true; PlayerPrefs.SetInt("LAA_VIAL", 1); reagent = Mathf.Min(9, reagent + 3); PlayerPrefs.SetInt("LAA_REAGENT", Mathf.FloorToInt(reagent)); hint = "VIAL unlocked: L throws a vial; reagent fuels it and mending."; }
            else { maxHp = Mathf.Min(9, maxHp + 1); hp = maxHp; hint = "A spare mask increases maximum health."; }
            PlayerPrefs.Save(); Destroy(it.gameObject); pickups.RemoveAt(i); pickupKinds.RemoveAt(i);
        }
    }

    private void UpdateArea()
    {
        float x = player.transform.position.x;
        currentArea = x < 19 ? Areas[0] : x < 40 ? Areas[1] : x < 62 ? Areas[2] : x < 84 ? Areas[3] : Areas[4];
    }

    private void Respawn()
    {
        hp = maxHp; invulnerable = 1.2f; rb.velocity = Vector2.zero; player.transform.position = new Vector3(checkpointX, checkpointY, 0);
    }

    private void OnGUI()
    {
        GUI.skin.label.fontSize = Mathf.Clamp(Screen.height / 42, 14, 25);
        GUI.skin.label.normal.textColor = new Color(.95f, .93f, .86f);
        GUI.skin.button.fontSize = Mathf.Clamp(Screen.height / 38, 16, 26);
        float cx = Screen.width * .5f;
        if (title) {
            GUI.Box(new Rect(cx - 230, 45, 460, Screen.height - 90), "");
            CenterLabel("THE LAST APOTHECARY — UNITY PROTOTYPE", cx, 95, 25);
            CenterLabel("Primitive art placeholders • no external assets", cx, 135, 16);
            if (GUI.Button(new Rect(cx - 110, 190, 220, 48), "New Game")) { ResetProgress(); title = false; paused = false; }
            if (GUI.Button(new Rect(cx - 110, 250, 220, 48), "Continue / Checkpoint")) { title = false; paused = false; player.transform.position = new Vector3(checkpointX, checkpointY, 0); }
            CenterLabel("A/D Move · Space Jump · J Strike · K Dash · E Interact", cx, 325, 15); return;
        }
        GUI.Box(new Rect(12, 12, 390, 88), "");
        GUI.Label(new Rect(25, 18, 360, 28), currentArea + "   HP " + hp + "/" + maxHp + "   Reagent " + reagent);
        GUI.Label(new Rect(25, 46, 370, 25), "Dash: " + (dashUnlocked ? "yes" : "not found") + "   Vial: " + (vialUnlocked ? "yes" : "not found"));
        GUI.Label(new Rect(25, 70, Screen.width - 50, 26), hint);
        if (showMap) { GUI.Box(new Rect(cx - 220, 90, 440, 230), "MAP — connected areas"); CenterLabel("CHAPEL → PLAGUE STREET → CISTERN → ROOT HALL → OSSUARY", cx, 155, 15); if (GUI.Button(new Rect(cx - 90, 240, 180, 45), "Close Map")) showMap = false; }
        if (paused) {
            GUI.Box(new Rect(cx - 190, 55, 380, 385), "PAUSED");
            if (GUI.Button(new Rect(cx - 120, 105, 240, 42), "Resume")) paused = false;
            if (GUI.Button(new Rect(cx - 120, 158, 240, 42), "Map")) { paused = false; showMap = true; }
            if (GUI.Button(new Rect(cx - 120, 211, 240, 42), "Back to Main Menu")) { SaveProgress(); title = true; paused = false; showMap = false; }
            CenterLabel("A/D or Arrows Move · Space Jump · J Strike · Q Mend", cx, 292, 14);
            CenterLabel("K/Shift Dash · L Vial · E Interact · M Map · Esc Pause", cx, 318, 14);
            CenterLabel("Checkpoint/progression is saved separately from menu state.", cx, 352, 13);
        }
    }

    private void CenterLabel(string value, float centerX, float y, int size)
    {
        var old = GUI.skin.label.fontSize; GUI.skin.label.fontSize = size;
        var r = new Rect(centerX - 450, y, 900, 40); var style = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = size, fontStyle = FontStyle.Bold };
        GUI.Label(r, value, style); GUI.skin.label.fontSize = old;
    }

    private void SaveProgress()
    {
        PlayerPrefs.SetFloat("LAA_CP_X", checkpointX); PlayerPrefs.SetFloat("LAA_CP_Y", checkpointY);
        PlayerPrefs.SetInt("LAA_DASH", dashUnlocked ? 1 : 0); PlayerPrefs.SetInt("LAA_VIAL", vialUnlocked ? 1 : 0);
        PlayerPrefs.SetInt("LAA_GATE", gateOpen ? 1 : 0); PlayerPrefs.SetInt("LAA_REAGENT", Mathf.FloorToInt(reagent)); PlayerPrefs.Save();
    }

    private void ResetProgress()
    {
        PlayerPrefs.DeleteKey("LAA_CP_X"); PlayerPrefs.DeleteKey("LAA_CP_Y"); PlayerPrefs.DeleteKey("LAA_DASH"); PlayerPrefs.DeleteKey("LAA_VIAL"); PlayerPrefs.DeleteKey("LAA_GATE"); PlayerPrefs.DeleteKey("LAA_REAGENT");
        checkpointX = 3; checkpointY = -1.5f; dashUnlocked = false; vialUnlocked = false; gateOpen = false; hp = maxHp = 5; reagent = 0;
        if (chapelGate) chapelGate.SetActive(true); player.transform.position = new Vector3(3, -1.5f, 0); SaveProgress();
    }
}

