# Unity native prototype starter (source-only)

This is a self-contained, primitive-art vertical slice intended as a **starting point for a native Unity port**, not an automatically converted full-parity version of the browser game. The complete game remains `../../index.html`.

## Create the scene

1. Use a recent Unity 2D project.
2. Save a new scene such as `Assets/Scenes/ApothecaryPrototype.unity`.
3. Copy `ApothecaryNativePrototype.cs` into `Assets/Scripts/`.
4. Create an empty GameObject named `ApothecaryBootstrap` and attach `ApothecaryNativePrototype`.
5. In **Project Settings → Player → Active Input Handling**, select **Input Manager (Old)** or **Both**; this starter uses Unity's built-in `Input.GetKey` API.
6. Press Play. The bootstrap script creates a camera, player, basic floors/stairs, areas, upgrade markers, checkpoints, a lever/gate placeholder, and patrol enemies using a generated white pixel sprite. No art files or package dependencies are required.

## Controls

- A/D or arrows: move
- Space or Up: jump, release early for a shorter jump
- J: strike
- Q: mend when grounded and holding at least 3 reagent
- K or Shift: dash after collecting the Dash marker
- L: vial action after collecting the Vial marker
- E: interact with nearby checkpoint / lever
- M: map overlay
- Esc: pause/resume

The pause UI includes **Resume**, **Map**, and **Back to Main Menu**. The latter saves checkpoint/upgrade/gate state to `PlayerPrefs` before returning to the title overlay.

## Scene and asset notes

All scenery is generated from colored square sprites, box colliders, and text labels. The Unity scene does not need imported assets. One-way stair blocks use `PlatformEffector2D`; a solid Chapel first step is included. You can replace placeholders with user-owned sprites/audio later.

## Known limitations

This is a native-engine starter vertical slice, not full parity with the nine-room HTML game. The sample places the five named core areas in a continuous prototype strip and simplifies room transitions, combat, effects, map topology, and persistence. It is source-only and was not compiled in Unity in this environment; resolve any version-specific API/editor warnings in the Unity editor before relying on it for release builds.
