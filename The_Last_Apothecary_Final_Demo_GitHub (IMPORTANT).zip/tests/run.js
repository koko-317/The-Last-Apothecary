'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const match = html.match(/<script>([\s\S]*?)<\/script>/i);
assert.ok(match, 'index.html contains an embedded game script');
const source = match[1];
new vm.Script(source, { filename: 'index.html inline game script' });
console.log('PASS: embedded game JavaScript parses');

const noop = () => {};
function makeGameContext() {
  const canvasHandlers = {};
  const makeContext2d = () => new Proxy({}, {
    get(target, key) {
      if (key in target) return target[key];
      if (key === 'createRadialGradient') return () => ({ addColorStop: noop });
      return noop;
    },
    set(target, key, value) { target[key] = value; return true; }
  });
  const makeCanvas = () => ({ width: 480, height: 272, style: {}, getContext: makeContext2d, addEventListener: (name, fn) => { canvasHandlers[name] = fn; }, getBoundingClientRect: () => ({ left: 0, top: 0, width: 480, height: 272 }) });
  const canvas = makeCanvas();
  const storage = {};
  class MockImage {
    constructor() { this.complete = false; this.naturalWidth = 0; this.naturalHeight = 0; this._src = ''; }
    set src(value) { this._src = String(value); this.complete = true; this.naturalWidth = value.includes('image/webp') ? 276 : 480; this.naturalHeight = value.includes('image/webp') ? 192 : 360; }
    get src() { return this._src; }
  }
  const sandbox = {
    console, Math, Uint8Array, JSON, Date, isFinite, Image: MockImage,
    document: { getElementById: () => canvas, createElement: makeCanvas },
    localStorage: { getItem: key => Object.prototype.hasOwnProperty.call(storage, key) ? storage[key] : null, setItem: (key, value) => { storage[key] = String(value); } },
    addEventListener: noop,
    requestAnimationFrame: noop,
    innerWidth: 960,
    innerHeight: 544
  };
  sandbox.window = sandbox;
  const context = vm.createContext(sandbox);
  vm.runInContext(source, context, { filename: 'index.html inline game script' });
  context.__canvasHandlers = canvasHandlers;
  context.__storage = storage;
  return context;
}
function setupCistern(context, x = 36.93, initialHitstop = 0.07) {
  vm.runInContext(`
    S = newS(); S.f.dash = 1;
    startPlay(); loadRoom(2, ${x}, 239.99); st = 'play';
    fade = 0; ban = null; E = []; B = null;
    p.x = ${x}; p.y = 239.99; p.vx = 0; p.vy = 0;
    p.on = true; p.dok = true; p.st = 'n'; p.inv = 0;
    hs = ${initialHitstop}; K = { KeyK: 1 }; PR = { KeyK: 1 };
  `, context);
}
function read(context, expression) { return vm.runInContext(expression, context); }
function close(actual, expected, epsilon = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= epsilon, `${actual} is not within ${epsilon} of ${expected}`);
}

// Reproduce the reported timing divergence: direct updP bypasses hitstop.
const planner = makeGameContext();
const realLoop = makeGameContext();
setupCistern(planner);
setupCistern(realLoop);
for (let i = 0; i < 6; i++) {
  vm.runInContext('updP(1/60); PR = {};', planner);
  vm.runInContext('step(1/60);', realLoop);
}
const plannerX = read(planner, 'p.x');
const realX = read(realLoop, 'p.x');
const realHs = read(realLoop, 'hs');
close(plannerX, 65.26333333333332);
close(realX, 36.93);
close(plannerX - realX, 28.33333333333332);
close(realHs, -0.013333333333333319);
console.log(`PASS: hitstop divergence reproduced (planner x=${plannerX.toFixed(2)}, step x=${realX.toFixed(2)}, Δ=${(plannerX-realX).toFixed(2)} px)`);

// Cistern-to-Ossuary focused route, driven through step() with simulated input edges.
const route = makeGameContext();
vm.runInContext(`
  S = newS(); S.f.dash = 1;
  startPlay(); loadRoom(2, 215, 239.99); st = 'play'; fade = 0; ban = null;
  E = []; B = null; p.x = 215; p.y = 239.99; p.vx = 0; p.vy = 0;
  p.on = true; p.sx = 215; p.sy = 239.99; p.inv = 0;
  K = { KeyD: 1 }; PR = {}; hs = 0;
`, route);
let fell = false;
let enteredOssuary = false;
let transitionFrames = null;
let frames = 0;
function routeFrame(code = '') {
  if (code) vm.runInContext(code, route);
  vm.runInContext('step(1/60);', route);
  frames++;
  const state = read(route, '({ room: cur, x: p.x, y: p.y, transition: !!tr })');
  if (state.y > 272) fell = true;
  if (state.transition && transitionFrames === null) transitionFrames = frames;
  if (state.room === 4) enteredOssuary = true;
  return state;
}
routeFrame('K.Space = 1; PR = { Space: 1 };');
for (let i = 2; i <= 15; i++) routeFrame('K.Space = 1; PR = {};');
routeFrame('K.Space = 1; K.KeyK = 1; PR = { KeyK: 1 };');
routeFrame('K.Space = 1; K.KeyK = 0; PR = {};');
for (let i = 0; i < 300 && !enteredOssuary && !fell; i++) routeFrame('K.Space = 1; PR = {};');
assert.equal(fell, false, 'assisted Cistern crossing does not fall into the pit');
assert.equal(enteredOssuary, true, 'route transitions from Cistern to Ossuary Stairs');
assert.ok(transitionFrames !== null, 'a room transition was observed');
assert.ok(frames <= 305, 'route reaches the target within the test frame limit');
console.log(`PASS: assisted Cistern → Ossuary route through step() (${frames} frames; enemies disabled; dash unlocked)`);

// Gate state only: verify collision flag behavior in Sealed Chapel.
const gate = makeGameContext();
vm.runInContext('S = newS(); startPlay(); loadRoom(0, 480, 239.99);', gate);
assert.equal(read(gate, 'sol(31, 6)'), true, 'sealed gate blocks the tile before its flag is set');
vm.runInContext('S.f.gate = 1; build();', gate);
assert.equal(read(gate, 'sol(31, 6)'), false, 'gate tile is clear after opening flag and rebuilding grid');
console.log('PASS: Sealed Chapel gate flag blocks/opens expected tile');

// Demo Edit 5 one-way platforms: upward and horizontal passage, downward landing,
// while visibility/projectiles continue to treat the plank as an obstruction.
const oneWay = makeGameContext();
vm.runInContext('S = newS(); startPlay(); loadRoom(1, 480, 239.99); st = \'play\'; fade = 0;', oneWay);
assert.equal(read(oneWay, 'grid[13*rw+30]'), 3, 'Plague Street first stair uses grid value 3');
assert.equal(read(oneWay, 'sol(30,13)'), true, 'plank remains solid to sight/projectile queries');
vm.runInContext('var testBody = {x:31*T+8,y:216,w:8,h:8,vx:0,vy:-120,on:false}; mv(testBody,0,-12);', oneWay);
close(read(oneWay, 'testBody.y'), 204, 1e-9);
console.log('PASS: player body can jump upward through a one-way plank');
vm.runInContext('testBody = {x:30*T+8,y:216,w:8,h:8,vx:0,vy:0,on:false}; mv(testBody,32,0);', oneWay);
close(read(oneWay, 'testBody.x'), 30*16+8+32, 1e-9);
console.log('PASS: player body can move horizontally through a one-way plank');
vm.runInContext('testBody = {x:31*T+8,y:204,w:8,h:8,vx:0,vy:480,on:false}; mv(testBody,0,8);', oneWay);
close(read(oneWay, 'testBody.y'), 13*16-0.01, 1e-9);
assert.equal(read(oneWay, 'testBody.on'), true, 'downward crossing lands on plank top');
console.log('PASS: downward crossing lands on a one-way plank');
// The same sol() query used by enemy ledge checks and player checkpoint sampling sees grid 3 as support.
assert.equal(read(oneWay, 'sol(31, Math.floor((13*T-.01+4)/T))'), true,
  'enemy ledge probe recognizes a one-way plank as ground');
vm.runInContext('p.x=31*T+8;p.y=13*T-.01;p.vx=0;p.vy=0;p.on=true;p.st=\'n\';p.sx=0;p.sy=0;K={};PR={};E=[];B=null;IT=[];PJ=[];updP(1/60);', oneWay);
close(read(oneWay, 'p.sy'), 13*16-.01, 1e-9);
console.log('PASS: enemy ledge support and player safe-respawn checkpoint sampling recognize planks');
assert.equal(read(oneWay, 'los({x:29*T+8,y:222,h:12},{x:34*T+8,y:222,h:12})'), false,
  'line of sight remains blocked by one-way plank');
vm.runInContext('E=[];B=null;IT=[];PJ=[{k: \'sp\',x:31*T+8,y:13*T+5,vx:0,l:4}];updWorld(1/60);', oneWay);
assert.equal(read(oneWay, 'PJ.length'), 0, 'a hostile projectile is consumed when it hits a plank');
console.log('PASS: one-way planks still block line of sight and projectiles');
const chapel = makeGameContext();
vm.runInContext('S = newS(); startPlay(); loadRoom(0, 200, 239.99);', chapel);
assert.equal(read(chapel, 'grid[13*rw+10]'), 1, 'Chapel first platform remains fully solid');
assert.equal(read(chapel, 'grid[12*rw+16]'), 3, 'the first one-way Chapel step is shifted left to make the next jump reachable');
console.log('PASS: Sealed Chapel first platform remains solid and the next one-way step is reachable by layout');
// Replay the formerly too-wide first staircase jump through real input edges and step().
vm.runInContext(`p.x=212;p.y=13*T-.01;p.vx=0;p.vy=0;p.on=true;p.co=.1;p.jb=0;p.st='n';p.inv=0;K={};PR={};hs=0;E=[];B=null;fade=0;ban=null;`, chapel);
vm.runInContext(`K={KeyD:1,Space:1};PR={Space:1};step(1/60);`, chapel);
let chapelLanded = false;
let chapelState;
for (let i=0; i<90; i++) {
  vm.runInContext(`K={KeyD:1,Space:1};PR={};step(1/60);`, chapel);
  chapelState = read(chapel, '({x:p.x,y:p.y,on:p.on,cur,transition:!!tr})');
  if (chapelState.on && Math.abs(chapelState.y-(12*16-.01))<0.05 && chapelState.x>=16*16-6 && chapelState.x<=19*16+6) { chapelLanded=true; break; }
}
assert.equal(chapelLanded, true, `Quarantine Quarter first stair jump lands on the next platform: ${JSON.stringify(chapelState)}`);
console.log('PASS: Quarantine Quarter stair jump is reachable through actual step() input simulation');
assert.ok(source.includes("if(v==3){const top=r.a===1?'#65704f':r.a===2?'#50736b':'#736348'"),
  'one-way platforms use the muted, room-aware weathered-wood palette and begin at the collision top');
console.log('PASS: one-way plank rendering aligns its visible top with the collision top');
vm.runInContext('drawDoorHints(R[cur]);', oneWay);
console.log('PASS: unexplored-exit hint rendering runs with the available canvas context');


// Pause UI: the visible Back to Main Menu button is clickable and retains checkpoint/save state.
const pauseUi = makeGameContext();
vm.runInContext(`S = newS(); S.f.dash=1; S.f.gate=1; S.rg=4; S.seen[2]=1; S.cp={r:2,x:215,y:239.99}; save(); st='pause';`, pauseUi);
assert.ok(read(pauseUi, "PAUSE_BTNS.some(b => b.label === 'Back to Main Menu')"), 'pause menu exposes a Back to Main Menu button');
const pointerdown = pauseUi.__canvasHandlers.pointerdown;
assert.equal(typeof pointerdown, 'function', 'canvas registers pointerdown for clickable pause buttons');
pointerdown({ clientX: 240, clientY: 129, preventDefault() {} });
assert.equal(read(pauseUi, 'st'), 'title', 'clicking Back to Main Menu returns to title screen immediately');
assert.equal(read(pauseUi, 'sv.cp.r'), 2, 'checkpoint room survives returning to title');
assert.equal(read(pauseUi, 'sv.cp.x'), 215, 'checkpoint x survives returning to title');
assert.equal(read(pauseUi, 'sv.f.dash'), 1, 'unlocked dash survives returning to title');
assert.equal(read(pauseUi, 'sv.f.gate'), 1, 'gate progression survives returning to title');
assert.equal(read(pauseUi, 'sv.rg'), 4, 'reagent count survives returning to title');
console.log('PASS: clickable Back to Main Menu immediately returns to title and preserves checkpoint/progression');
assert.ok(/<title>The Last Apothecary — Final Demo<\/title>/.test(html), 'browser tab identifies Final Demo');
assert.ok(source.includes("tx('FINAL DEMO'"), 'title screen displays Final Demo label');
assert.ok(source.includes('\\"Trebuchet MS\\"') || source.includes('Trebuchet MS'), 'UI uses a readable system sans-serif font fallback');
console.log('PASS: Final Demo browser/title labels and readable high-contrast font styling');

// Title menu arrows must move in their named direction, including wraparound.
const titleNav = makeGameContext();
vm.runInContext('toTitle(); mi=1; K={}; PR={ArrowUp:1}; menuStep();', titleNav);
assert.equal(read(titleNav, 'mi'), 0, 'ArrowUp moves selection toward the previous title-menu item');
vm.runInContext('PR={}; K={}; PR={ArrowDown:1}; menuStep();', titleNav);
assert.equal(read(titleNav, 'mi'), 1, 'ArrowDown moves selection toward the next title-menu item');
vm.runInContext('mi=0; PR={ArrowUp:1}; menuStep();', titleNav);
assert.equal(read(titleNav, 'mi'), read(titleNav, 'opts.length-1'), 'ArrowUp wraps from the first title-menu item to the final item');
console.log('PASS: title menu Up/Down selection moves in the correct direction and wraps');

// Rootbound Ossuary: the stairs are one-way so their collision cannot seal off the lower route.
const ossuary = makeGameContext();
vm.runInContext(`
  S = newS(); startPlay(); loadRoom(4, 25.6, 239.99); st = 'play'; fade = 0; ban = null;
  E = []; B = null; p.x = 25.6; p.y = 239.99; p.vx = 0; p.vy = 0;
  p.on = true; p.co = .1; p.inv = 0; K = { KeyD: 1 }; PR = {}; hs = 0;
`, ossuary);
for (const [x, y] of [[10,13],[7,11],[4,9],[1,7],[22,11]]) {
  assert.equal(read(ossuary, `grid[${y}*rw+${x}]`), 3, `Ossuary platform ${x},${y} is one-way`);
  assert.equal(read(ossuary, `sol(${x},${y})`), true, `Ossuary platform ${x},${y} still blocks LOS/projectiles`);
}
let enteredRootHall = false;
let ossuaryFrames = 0;
for (; ossuaryFrames < 360 && !enteredRootHall; ossuaryFrames++) {
  vm.runInContext('step(1/60);', ossuary);
  enteredRootHall = read(ossuary, 'cur === 5');
}
assert.equal(enteredRootHall, true, 'player can pass the Ossuary stair block and reach the Root Hall exit through step()');
assert.ok(ossuaryFrames < 360, 'Root Hall is reached within the input simulation limit');
console.log(`PASS: Rootbound Ossuary one-way stair route reaches Root Hall through step() (${ossuaryFrames} frames; enemies disabled)`);
assert.ok(html.includes("image-rendering:auto"), 'canvas scaling uses smoother text rendering instead of pixelating the UI');
assert.ok(source.includes("'Arial, Verdana, \\\"Trebuchet MS\\\", \\\"Segoe UI\\\", sans-serif'") || source.includes('Arial, Verdana'), 'UI uses a bold high-legibility system sans-serif stack');
assert.ok(source.includes('MOVE: A/D OR ARROWS') && source.includes('rgba(4,6,10,.95)'), 'title instructions use a high-contrast backing panel and larger labels');
assert.equal(source.includes('HIDDEN ROOT LADDER: HOLD UP / W'), false, 'title screen does not spoil the secret ladder entrance');
console.log('PASS: title and pause instruction typography is larger, high-contrast, and smoother when scaled');


// ===== WHOLE-WORLD REACHABILITY AUDIT (all room routes driven through step()) =====
function worldFrame(ctx, keys = [], edges = []) {
  const held = Object.fromEntries(keys.map(k => [k, 1]));
  const pressed = Object.fromEntries(edges.map(k => [k, 1]));
  vm.runInContext(`K=${JSON.stringify(held)}; PR=${JSON.stringify(pressed)}; step(1/60);`, ctx);
}
function worldState(ctx) {
  return read(ctx, '({room:cur,x:p.x,y:p.y,on:p.on,vx:p.vx,vy:p.vy,st:p.st,tr:tr?{to:tr.to,di:tr.di}:null})');
}
function makeRouteRoom(roomIndex, x, gate = 0) {
  const ctx = makeGameContext();
  vm.runInContext(`S=newS(); S.f.dash=1; S.f.vial=1; S.f.gate=${gate}; S.f.boss=1;
    startPlay(); loadRoom(${roomIndex},${x},239.99); st='play'; fade=0; ban=null;
    E=[]; B=null; PJ=[]; hs=0; K={}; PR={};`, ctx);
  return ctx;
}
function walkUntil(ctx, predicate, keys, limit, label) {
  for (let n = 0; n < limit; n++) {
    if (predicate(worldState(ctx))) return n;
    worldFrame(ctx, keys);
  }
  assert.fail(`${label}: timed out; final state ${JSON.stringify(worldState(ctx))}`);
}
function jumpLandAt(ctx, direction, targetY, holdFrames = 22, limit = 65, label = 'stair') {
  worldFrame(ctx, [direction, 'Space'], ['Space']);
  for (let i = 1; i < holdFrames; i++) worldFrame(ctx, [direction, 'Space']);
  for (let i = 0; i < limit; i++) {
    worldFrame(ctx, []);
    const state = worldState(ctx);
    if (state.tr) assert.fail(`${label}: transitioned unexpectedly: ${JSON.stringify(state)}`);
    if (state.on && Math.abs(state.y - (targetY - .01)) < .1) return state;
    assert.ok(state.y < 272 + 30, `${label}: player fell out of the room`);
  }
  assert.fail(`${label}: did not land on row ${targetY}; final state ${JSON.stringify(worldState(ctx))}`);
}

// Every room's exits reference valid, reciprocal target doors; every room is
// reachable from the starting Chapel even with the Chapel shortcut still locked.
const worldGraphCtx = makeGameContext();
const worldRooms = read(worldGraphCtx, 'R.map((r,i)=>({i,n:r.n,w:r.w,d:r.d.map(d=>Array.from(d)),gate:r.gate?Array.from(r.gate):null,hidden:[r.secretDrop?.to,r.vine?.to,r.secretReturn?.to].filter(v=>v!==undefined)}))');
assert.equal(worldRooms.length, 11, 'all eleven authored rooms are present');
for (const room of worldRooms) {
  assert.ok(room.d.length > 0 || room.hidden.length > 0, `${room.n} has at least one ordinary or hidden exit`);
  room.d.forEach((d, di) => {
    assert.ok(Number.isInteger(d[3]) && d[3] >= 0 && d[3] < worldRooms.length, `${room.n} door ${di} targets an existing room`);
    assert.ok(Number.isInteger(d[4]) && d[4] >= 0 && d[4] < worldRooms[d[3]].d.length, `${room.n} door ${di} targets an existing door`);
    const back = worldRooms[d[3]].d[d[4]];
    assert.equal(back[3], room.i, `${room.n} door ${di} is linked back to its source room`);
    assert.equal(back[4], di, `${room.n} door ${di} is linked back to the matching source doorway`);
  });
}
const reachableRooms = new Set([0]);
const pendingRooms = [0];
while (pendingRooms.length) {
  const ri = pendingRooms.shift();
  const room = worldRooms[ri];
  for (const d of room.d) {
    // Treat both high Chapel-gate sides as locked until the Root Hall lever is pulled.
    if (room.gate && d[1] === room.gate[1]) continue;
    if (!reachableRooms.has(d[3])) { reachableRooms.add(d[3]); pendingRooms.push(d[3]); }
  }
  for (const target of room.hidden) if (!reachableRooms.has(target)) { reachableRooms.add(target); pendingRooms.push(target); }
}
assert.equal(reachableRooms.size, 11, 'all eleven rooms are reachable from the starting Chapel with the gate closed');
console.log('PASS: world graph audit — 11/11 rooms reachable, every exit has a reciprocal valid target, Chapel shortcut may remain locked');

// Every door's destination spawn point must land within the room and outside solid collision.
const spawnAudit = makeGameContext();
vm.runInContext('S=newS(); S.f.gate=1; S.f.boss=1; startPlay();', spawnAudit);
let spawnCount = 0;
for (const room of worldRooms) for (const d of room.d) {
  const target = d[3], targetDoor = d[4];
  const spawn = read(spawnAudit, `spawnAt(${target},${targetDoor})`);
  vm.runInContext(`loadRoom(${target},${spawn[0]},${spawn[1]});`, spawnAudit);
  assert.ok(read(spawnAudit, 'p.x>0 && p.x<rw*T'), `${worldRooms[target].n}: doorway spawn is inside room bounds`);
  assert.ok(read(spawnAudit, 'p.y>0 && p.y<H'), `${worldRooms[target].n}: doorway spawn is inside vertical bounds`);
  assert.equal(read(spawnAudit, 'coll(p,"solid")'), false, `${worldRooms[target].n}: doorway spawn does not overlap a solid wall/platform`);
  spawnCount++;
}
console.log(`PASS: all ${spawnCount} doorway spawn points land inside their destination rooms without solid overlap`);

// Verify simple reciprocal doors in the live update loop as well as the deeper
// jump routes below. These moves use normal input, not teleporting to destination rooms.
function verifyWalkExit(room, x, key, target, label, limit = 450) {
  const ctx = makeRouteRoom(room, x, 0);
  let destination = null;
  for (let i = 0; i < limit; i++) {
    worldFrame(ctx, [key]);
    const state = worldState(ctx);
    if (state.tr || state.room !== room) { destination = state.tr ? state.tr.to : state.room; break; }
  }
  assert.equal(destination, target, `${label}: expected room ${target}, got ${destination}`);
  console.log(`PASS: room route — ${label}`);
}
verifyWalkExit(1, 688, 'KeyD', 2, 'Plague Street → Cistern Gate');
verifyWalkExit(2, 25.6, 'KeyA', 1, 'Cistern Gate → Plague Street');
verifyWalkExit(3, 25.6, 'KeyA', 1, 'Apothecary Vault → Plague Street');
verifyWalkExit(4, 614, 'KeyA', 2, 'Ossuary Stairs → Cistern Gate');
verifyWalkExit(6, 25.6, 'KeyA', 5, 'Flooded Wards → Root Hall');
verifyWalkExit(7, 454, 'KeyA', 6, 'Bellkeeper’s Chamber → Flooded Wards');

// Starting-room lower exit remains usable while the Chapel high gate is locked.
const chapelLowRoute = makeRouteRoom(0, 88, 0);
walkUntil(chapelLowRoute, st => st.x >= 130, ['KeyD'], 80, 'Chapel approach');
worldFrame(chapelLowRoute, ['KeyD','Space'], ['Space']);
for (let i = 1; i < 22; i++) worldFrame(chapelLowRoute, ['KeyD','Space']);
walkUntil(chapelLowRoute, st => st.on && Math.abs(st.y - 207.99) < .1, [], 60, 'Chapel lower solid platform landing');
for (let i = 0; i < 300; i++) {
  worldFrame(chapelLowRoute, ['KeyD']);
  const st = worldState(chapelLowRoute);
  if (st.tr) break;
}
assert.equal(read(chapelLowRoute, 'tr && tr.to'), 1, 'Quarantine Quarter lower exit reaches Plague Street without opening the high gate');
assert.equal(read(chapelLowRoute, 'S.f.gate'), 0, 'lower route does not silently unlock the Chapel gate');
console.log('PASS: Quarantine Quarter → Plague Street low exit works while the high gate is locked');

// Full Cistern entrance route: dash after jumping, then traverse the entire pit to Ossuary.
const cisternFromEntrance = makeRouteRoom(2, 25.6, 0);
walkUntil(cisternFromEntrance, st => st.x >= 220 && st.on, ['KeyD'], 180, 'Cistern pit edge');
worldFrame(cisternFromEntrance, ['KeyD','Space'], ['Space']);
for (let i = 1; i < 18; i++) worldFrame(cisternFromEntrance, ['KeyD','Space']);
worldFrame(cisternFromEntrance, ['KeyD','KeyK'], ['KeyK']);
let cisternDestination = null;
for (let i = 0; i < 420; i++) {
  worldFrame(cisternFromEntrance, ['KeyD']);
  const st = worldState(cisternFromEntrance);
  assert.ok(st.y < 272 + 30, 'Cistern crossing does not fall out before catching the far ledge');
  if (st.tr || st.room === 4) { cisternDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(cisternDestination, 4, 'actual left-side Cistern entrance crosses the full gap and reaches Ossuary Stairs');
console.log('PASS: full Cistern entrance → Ossuary route through step() (dash unlocked, enemies disabled)');

// Root Hall deliberately keeps its stair solid. A one-tile-deep trench under it
// makes a safe alternate walking route, rather than making every stair one-way.
const rootDipLayout = makeRouteRoom(5, 25.6, 0);
assert.equal(read(rootDipLayout, 'grid[13*rw+9]'), 1, 'Root Hall lower stair is still solid');
assert.equal(read(rootDipLayout, 'grid[11*rw+6]'), 1, 'Root Hall middle stair is still solid');
assert.equal(read(rootDipLayout, 'grid[9*rw+1]'), 1, 'Root Hall upper stair is still solid');
for (let x = 1; x <= 12; x++) {
  assert.equal(read(rootDipLayout, `grid[15*rw+${x}]`), 0, `Root Hall dip tile ${x} is open at walking-floor height`);
  assert.ok(read(rootDipLayout, `grid[16*rw+${x}]`) > 0, `Root Hall dip tile ${x} has a safe lower floor`);
}
assert.equal(read(rootDipLayout, 'grid[15*rw+0]'), 1, 'Root Hall keeps a solid ledge at the low doorway for jumping back to exit height');
console.log('PASS: Root Hall uses a safe dip under a still-solid lower stair, with the upper stairs remaining solid');

// Traverse the Root Hall dip from the Ossuary side, jump out on the far side,
// and enter Flooded Wards through the real update loop.
const rootDipRoute = makeRouteRoom(5, 25.6, 0);
let rootDipJumped = false, rootDipJumpHold = 0, rootDipDestination = null;
for (let f = 0; f < 500; f++) {
  const before = worldState(rootDipRoute);
  let keys = ['KeyD'], edges = [];
  if (before.y > 249 && before.x > 198 && before.on && !rootDipJumped) {
    keys = ['KeyD','Space']; edges = ['Space']; rootDipJumped = true; rootDipJumpHold = 8;
  } else if (rootDipJumpHold > 0) {
    keys = ['KeyD','Space']; rootDipJumpHold--;
  }
  worldFrame(rootDipRoute, keys, edges);
  const after = worldState(rootDipRoute);
  assert.ok(after.y < 272 + 30, 'Root Hall dip is not a lethal pit');
  if (after.tr || after.room === 6) { rootDipDestination = after.tr ? after.tr.to : after.room; break; }
}
assert.equal(rootDipJumped, true, 'player drops below the lower Root Hall stair and can jump out');
assert.equal(rootDipDestination, 6, 'Root Hall dip route reaches Flooded Wards');
console.log('PASS: Root Hall dip → jump out → Flooded Wards through step()');

// Return the other way: enter the dip from the right side, pass underneath the
// still-solid lower stair, jump out on the left, then take the low Ossuary exit.
const rootToOssuaryRoute = makeRouteRoom(5, 488, 0);
walkUntil(rootToOssuaryRoute, st => st.x <= 24 && st.y > 249 && st.on, ['KeyA'], 260, 'Root Hall dip from right side to the left ledge');
const dipEntryState = worldState(rootToOssuaryRoute);
assert.ok(dipEntryState.x >= 19 && dipEntryState.x <= 26, 'player can walk underneath the complete solid staircase to the left ledge');
worldFrame(rootToOssuaryRoute, ['KeyA','Space'], ['Space']);
for (let i=1;i<18;i++) worldFrame(rootToOssuaryRoute, ['KeyA','Space']);
let ossuaryLowDestination = null;
for (let i = 0; i < 120; i++) {
  worldFrame(rootToOssuaryRoute, ['KeyA']);
  const st = worldState(rootToOssuaryRoute);
  if (st.tr || st.room === 4) { ossuaryLowDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(ossuaryLowDestination, 4, 'Root Hall dip can be crossed backward and the low doorway returns to Ossuary Stairs');
console.log('PASS: Root Hall dip is reversible; right side → dip → left low exit → Ossuary Stairs');

// From Flooded Wards, jump both pits and reach the Bellkeeper room.
const floodedRoute = makeRouteRoom(6, 24, 0);
walkUntil(floodedRoute, st => st.x >= 175 && st.on, ['KeyD'], 130, 'Flooded Wards pit one');
worldFrame(floodedRoute, ['KeyD','Space'], ['Space']);
for (let i = 1; i < 22; i++) worldFrame(floodedRoute, ['KeyD','Space']);
walkUntil(floodedRoute, st => st.on && st.y < 240.1, [], 60, 'Flooded Wards pit one landing');
walkUntil(floodedRoute, st => st.x >= 383 && st.on, ['KeyD'], 180, 'Flooded Wards pit two');
worldFrame(floodedRoute, ['KeyD','Space'], ['Space']);
for (let i = 1; i < 22; i++) worldFrame(floodedRoute, ['KeyD','Space']);
walkUntil(floodedRoute, st => st.on && st.y < 240.1, [], 60, 'Flooded Wards pit two landing');
let bellkeeperDestination = null;
for (let i = 0; i < 220; i++) {
  worldFrame(floodedRoute, ['KeyD']);
  const st = worldState(floodedRoute);
  if (st.tr || st.room === 7) { bellkeeperDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(bellkeeperDestination, 7, 'Flooded Wards exit reaches Bellkeeper’s Chamber after crossing both pits');
console.log('PASS: Flooded Wards → Bellkeeper’s Chamber through step() after crossing both floor gaps');
assert.equal(read(floodedRoute, 'R[6].s[1][4]'), 3, 'ordinary pit bridge is a one-way plank that catches a downward jump landing');
console.log('PASS: Flooded Wards mid-route bridge is collision-backed, themed, and leads to the Bellkeeper exit');

// Climb Plague Street's four stairs without dash and pass through the upper Vault exit.
const plagueVaultRoute = makeRouteRoom(1, 25.6, 0);
walkUntil(plagueVaultRoute, st => st.x >= 448 && st.on, ['KeyD'], 500, 'Plague Street stair approach');
const plagueTops = [208,176,144,112], plagueHolds = [22,16,17,20];
for (let i = 0; i < plagueTops.length; i++) {
  jumpLandAt(plagueVaultRoute, 'KeyD', plagueTops[i], plagueHolds[i], 55, `Plague Street stair ${i+1}`);
}
walkUntil(plagueVaultRoute, st => st.x >= 688, ['KeyD'], 80, 'Plague Street upper exit edge');
worldFrame(plagueVaultRoute, ['KeyD','Space'], ['Space']);
let vaultDestination = null;
for (let i = 0; i < 50; i++) {
  worldFrame(plagueVaultRoute, ['KeyD','Space']);
  const st = worldState(plagueVaultRoute);
  if (st.tr || st.room === 3) { vaultDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(vaultDestination, 3, 'Plague Street upper stair exit reaches Apothecary Vault without dash already unlocked');
console.log('PASS: Plague Street four-step climb → Apothecary Vault via the real step() loop');

// Confirm the Vault dash relic is reachable from its entry side by using the
// solid shelf as a normal jump-on platform, not by phasing through it.
const vaultRelicRoute = makeRouteRoom(3, 25.6, 0);
walkUntil(vaultRelicRoute, st => st.x >= 219 && st.on, ['KeyD'], 150, 'Vault shelf approach');
worldFrame(vaultRelicRoute, ['KeyD','Space'], ['Space']);
for (let i = 1; i < 22; i++) worldFrame(vaultRelicRoute, ['KeyD','Space']);
walkUntil(vaultRelicRoute, st => st.on && Math.abs(st.y - 223.99) < .1, [], 65, 'Vault shelf landing');
for (let i = 0; i < 18; i++) worldFrame(vaultRelicRoute, ['KeyD']);
assert.equal(read(vaultRelicRoute, 'S.f.dash'), 1, 'landing/walking across the Vault shelf collects the dash relic');
console.log('PASS: Apothecary Vault dash relic can be collected via its solid shelf and normal jump');

// Climb Ossuary's four upper stairs and take the high exit to Reliquary.
const ossuaryReliquaryRoute = makeRouteRoom(4, 616, 0);
walkUntil(ossuaryReliquaryRoute, st => st.x <= 250 && st.on, ['KeyA'], 300, 'Ossuary stair approach');
for (const [i, top] of [208,176,144,112].entries()) {
  jumpLandAt(ossuaryReliquaryRoute, 'KeyA', top, 22, 60, `Ossuary stair ${i+1}`);
}
let reliquaryDestination = null;
for (let i = 0; i < 50; i++) {
  worldFrame(ossuaryReliquaryRoute, ['KeyA']);
  const st = worldState(ossuaryReliquaryRoute);
  if (st.tr || st.room === 8) { reliquaryDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(reliquaryDestination, 8, 'Ossuary upper exit can be reached from its four-step stair route');
console.log('PASS: Ossuary four-step climb → Reliquary upper exit through step()');

// Reach Root Hall's lever from the Flooded Wards/right side, unlock the Chapel
// gate, and prove that the high return exit then opens to the Chapel.
const rootLeverRoute = makeRouteRoom(5, 488, 0);
walkUntil(rootLeverRoute, st => st.x <= 248 && st.on, ['KeyA'], 300, 'Root Hall lever stair approach');
for (const [i, top] of [208,176,144].entries()) {
  jumpLandAt(rootLeverRoute, 'KeyA', top, 22, 60, `Root Hall stair ${i+1}`);
}
worldFrame(rootLeverRoute, ['KeyE'], ['KeyE']);
assert.equal(read(rootLeverRoute, 'S.f.gate'), 1, 'Root Hall lever is reachable and opens the Chapel gate');
assert.equal(read(rootLeverRoute, 'sol(0,6)'), false, 'the corresponding Root Hall high doorway is open after pulling the lever');
let chapelHighDestination = null;
for (let i = 0; i < 80; i++) {
  worldFrame(rootLeverRoute, ['KeyA']);
  const st = worldState(rootLeverRoute);
  if (st.tr || st.room === 0) { chapelHighDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(chapelHighDestination, 0, 'opened Root Hall high exit returns to Sealed Chapel');
console.log('PASS: Root Hall stair climb reaches the lever; pulling it opens the high Chapel shortcut');

// Reliquary's low exit returns to the upper Ossuary doorway; the two rooms are
// reachable in both directions even though their doorway heights differ.
const reliquaryReturn = makeRouteRoom(8, 24, 1);
walkUntil(reliquaryReturn, st => st.x >= 124 && st.on, ['KeyD'], 110, 'Reliquary shelf approach');
jumpLandAt(reliquaryReturn, 'KeyD', 224, 22, 65, 'Reliquary exit shelf');
let ossuaryReturnDestination = null;
for (let i = 0; i < 180; i++) {
  worldFrame(reliquaryReturn, ['KeyD']);
  const st = worldState(reliquaryReturn);
  if (st.tr || st.room === 4) { ossuaryReturnDestination = st.tr ? st.tr.to : st.room; break; }
}
assert.equal(ossuaryReturnDestination, 4, 'Reliquary exit returns to Ossuary Stairs after jumping the solid shelf');
console.log('PASS: Reliquary solid shelf is jumpable and its exit returns to Ossuary, completing the upper-room connection');


// Requested cleanup: no Root Dip instructional text remains in the game UI.
assert.equal(read(worldGraphCtx, "R[5].t.some(a => a[2].includes('ROOT DIP'))"), false,
  'Root Hall no longer displays the Root Dip instruction');
assert.ok(source.includes("'The lever opens the high gate in the Chapel.'"),
  'Root Hall keeps the useful Chapel lever hint');
console.log('PASS: removed Root Dip overlay text while keeping the Chapel lever hint');

// The Bellkeeper cannot charge through the open low doorway and leave the visible arena.
const bossBounds = makeGameContext();
vm.runInContext(`S=newS();startPlay();loadRoom(7,200,239.99);st='play';E=[];p.x=200;p.y=239.99;p.st='n';p.inv=0;
  B.x=35;B.y=239.99;B.s='charge';B.t=1;B.did=1;B.cf=-1;B.f=-1;B.vx=0;B.inv=0;K={};PR={};hs=0;`, bossBounds);
vm.runInContext('updB(1/60);', bossBounds);
assert.ok(read(bossBounds, 'B.x >= T+B.w/2+2 && B.x <= rw*T-T-B.w/2-2'),
  'boss stays within the arena bounds during a side charge');
assert.equal(read(bossBounds, 'B.s'), 'stun', 'boss is stopped/stunned when its charge reaches the arena edge');
assert.ok(read(bossBounds, 'B.x-B.w/2 >= 0 && B.x+B.w/2 <= W'), 'boss body remains entirely on-screen in the Bellkeeper room');
const bossRight = makeGameContext();
vm.runInContext(`S=newS();startPlay();loadRoom(7,200,239.99);st='play';E=[];p.x=200;p.y=239.99;p.st='n';p.inv=0;
  B.x=445;B.y=239.99;B.s='charge';B.t=1;B.did=1;B.cf=1;B.f=1;B.vx=0;B.inv=0;K={};PR={};hs=0;`, bossRight);
vm.runInContext('updB(1/60);', bossRight);
assert.ok(read(bossRight, 'B.x >= T+B.w/2+2 && B.x <= rw*T-T-B.w/2-2'), 'boss is bounded at right arena edge too');
assert.equal(read(bossRight, 'B.s'), 'stun', 'right-edge charge also enters stun');
console.log('PASS: Bellkeeper side charge is bounded by the screen arena and stuns at the edge');

// Credits are a usable title-screen item and credit John Kokoska.
const credits = makeGameContext();
vm.runInContext("S=newS();sv=null;opts=['New Game','Credits'];mi=1;st='title';K={Enter:1};PR={Enter:1};menuStep();", credits);
assert.equal(read(credits, 'st'), 'credits', 'choosing Credits from the title menu opens the credits screen');
vm.runInContext('draw();', credits);
assert.ok(source.includes("tx('John Kokoska'"), 'credits screen credits John Kokoska');
vm.runInContext("K={Escape:1};PR={Escape:1};menuStep();", credits);
assert.equal(read(credits, 'st'), 'title', 'Escape returns from Credits to the title menu');
console.log('PASS: title-screen Credits displays John Kokoska and returns cleanly to the menu');

// Easter eggs must be genuinely hidden branches, not obvious side doors or floating stair sequences.
assert.equal(read(worldGraphCtx, "R[9].n"), 'Risk of Rainfall', 'Risk of Rain reference room exists');
assert.equal(read(worldGraphCtx, "R[10].n"), 'The Pale Burrow', 'Hollow Knight reference room exists');
assert.deepEqual(Array.from(read(worldGraphCtx, 'R[9].m')), [4,3], 'Risk of Rainfall sits below Flooded Wards in map layout');
assert.deepEqual(Array.from(read(worldGraphCtx, 'R[10].m')), [2,0], 'Pale Burrow is a separate upper branch in map layout');
assert.equal(read(worldGraphCtx, 'R[6].secretDrop.to'), 9, 'Risk of Rainfall is connected through a hidden floor drop in Flooded Wards');
assert.equal(read(worldGraphCtx, 'R[9].secretReturn.to'), 6, 'Risk of Rainfall has a concealed side-hatch return to Flooded Wards');
assert.equal(read(worldGraphCtx, 'R[9].secretReturn.x'), 16*16+8, 'Risk of Rainfall return spawn is beyond the entrance hole, not above it');
assert.equal(read(worldGraphCtx, 'R[9].secretReturn.resetInput'), true, 'Risk of Rainfall hatch clears held input at the transition to prevent an immediate re-entry');
assert.equal(read(worldGraphCtx, 'R[6].s.length'), 2, 'Flooded Wards keeps only the connected approach step and gap bridge instead of disconnected later steps');
assert.equal(read(worldGraphCtx, 'R[6].s[1][0]'), 25, 'Flooded Wards has a one-way bridge across the ordinary pit');
assert.equal(read(worldGraphCtx, 'R[10].w'), 30, 'Pale Burrow room width matches the 480-pixel pixel-art reference');
assert.equal(read(worldGraphCtx, 'R[4].vine.to'), 10, 'Pale Burrow is connected through the Ossuary vine ladder');
assert.equal(read(worldGraphCtx, 'R[10].vine.to'), 4, 'Pale Burrow has a vine-ladder return to the Ossuary');
assert.equal(read(worldGraphCtx, 'R[6].d.some(d=>d[3]===9)'), false, 'Flooded Wards has no obvious standard door to Risk of Rainfall');
assert.equal(read(worldGraphCtx, 'R[4].d.some(d=>d[3]===10)'), false, 'Ossuary has no obvious standard door to Pale Burrow');
assert.ok(source.includes('function drawLunarTeleporter') && !source.includes('g.drawImage(ART.riskGate,102,48)'),
  'Risk of Rain lunar gate is drawn as in-world procedural pixel art rather than a pasted screenshot');
assert.ok(!source.includes('const ART=') && !source.includes('data:image/') && !source.includes('artReady('),
  'the full-screen reference screenshots and their embedded data blobs are absent from the shipping HTML');
assert.ok(source.includes('function drawPaleBench') && !source.includes('g.drawImage(ART.paleBench,0,0)'),
  'Hollow Knight bench scene is drawn procedurally rather than using a full-screen pasted image');
assert.ok(source.includes("The Knight's small, seated pose") && source.includes('Horned white shell') && source.includes('scale=.72'),
  'The Knight is drawn in a seated pose directly on the classic save-point bench');
assert.equal(read(worldGraphCtx, 'R[10].s'), undefined, 'Pale Burrow has no extra floating stair/platform in front of the crawl opening');
assert.equal(read(worldGraphCtx, 'R[10].t'), undefined, 'Pale Burrow has no old overlay text that can collide visually with the bench scene');
assert.ok(source.includes('if(cur===10)drawPaleBench()'), 'Pale Burrow focal art is rendered from the bench-scene drawer');
assert.ok(source.includes('Incognito ladder: thin root tendrils woven into the wall'), 'hidden vine access blends with the room wall');
assert.ok(source.includes('Moon terrain and the distant Commencement citadel') && source.includes('scale=.82'), 'Risk of Rain gate includes the moon/Mithrix destination and is scaled to the game world');
assert.ok(source.includes('not a separate platform in front of a doorway'), 'Pale Burrow bench scene uses no extra doorway platform');
assert.ok(source.includes('rotten, moss-veiled floor seam'), 'Risk of Rainfall entrance is visually disguised as a decayed floor patch');
assert.ok(source.includes('map only draws the dotted secret connection') || source.includes('!S.seen[i]||!S.seen[to]'), 'secret connector is not shown before both rooms are discovered');
console.log('PASS: secret-room layout uses a Flooded Wards drop and a hidden Ossuary vine ladder; the Pale Burrow has no floating stairs');

// Risk of Rainfall is reached by falling through the overgrown first floor gap, using real step() frames.
const rainfallRoute = makeRouteRoom(6, 13*16+8, 0);
let rainfallDestination = null, rainfallFell = false;
for (let i=0; i<100 && rainfallDestination===null; i++) {
  worldFrame(rainfallRoute, []);
  const z=worldState(rainfallRoute);
  if(z.y>272) rainfallFell=true;
  if(z.room===9) rainfallDestination=9;
}
assert.equal(rainfallDestination,9,'falling through Flooded Wards overgrown gap enters Risk of Rainfall');
assert.equal(read(rainfallRoute,'S.ach.secret_rain'),1,'real-world transition to Risk of Rainfall awards its achievement');
assert.equal(rainfallFell,true,'the secret is triggered by falling through the gap rather than using a normal side door');
console.log('PASS: Flooded Wards secret drop → Risk of Rainfall through the real step() loop');
// Reproduce the user's fall-loop: the old return spawn was x=216, inside the x=192..239 hole.
// The new hatch must return beyond that hole, release the exit key, and leave the player safely in Wards.
const escapeLoop = makeRouteRoom(9, 15*16+8, 0);
worldFrame(escapeLoop, ['KeyA']);
let escapeDestination = null;
for (let i=0; i<190; i++) { worldFrame(escapeLoop, ['KeyA']); const z=worldState(escapeLoop); if(z.room===6){escapeDestination=6;break;} }
assert.equal(escapeDestination,6,'Risk of Rainfall hatch returns to Flooded Wards');
assert.equal(read(escapeLoop, 'p.x'), 16*16+8, 'Risk return spawn is beyond the drop hole on safe ground');
assert.deepEqual(Object.keys(read(escapeLoop, 'K')), [], 'held direction input is cleared after the secret return transition');
for(let i=0;i<90;i++)worldFrame(escapeLoop,[]);
assert.equal(read(escapeLoop, 'cur'),6,'the returned player remains in Flooded Wards rather than falling into Risk repeatedly');
assert.ok(read(escapeLoop, 'p.x') > (15*16), 'the player stays on the forward side of the hidden drop');
console.log('PASS: Risk of Rainfall exit no longer loops into the same hole; return spawn and input reset are safe');
verifyWalkExit(9,25.6,'KeyA',6,'Risk of Rainfall → Flooded Wards concealed low hatch return');

// The Pale Burrow is reached by climbing the hidden vines in Ossuary Stairs and pressing E at the root seam.
const paleEntryRoute = makeRouteRoom(4, 17*16+8, 0);
let paleReachedTop = false;
for (let i=0;i<110;i++) {
  worldFrame(paleEntryRoute, ['KeyW']);
  const z=worldState(paleEntryRoute);
  if(z.y<=8*16+.5){paleReachedTop=true;break;}
}
assert.equal(paleReachedTop,true,'player can climb the concealed Ossuary vine ladder to its upper root seam');
worldFrame(paleEntryRoute,['KeyW','KeyE'],['KeyE']);
let paleDestination=null;
for(let i=0;i<30;i++){worldFrame(paleEntryRoute,[]);const z=worldState(paleEntryRoute);if(z.room===10){paleDestination=z.room;break}}
assert.equal(paleDestination,10,'pressing E at the top of the Ossuary vine ladder enters Pale Burrow');
assert.equal(read(paleEntryRoute,'S.ach.secret_burrow'),1,'real-world transition to the Pale Burrow awards its achievement');
console.log('PASS: Ossuary hidden vine ladder → Pale Burrow through actual step() frames');

// Returning from the hidden room requires climbing its own root ladder, not a visible floating stair.
const paleReturn=makeRouteRoom(10,24*16+8,0);
let paleReturnAtTop=false;
for(let i=0;i<110;i++){
  worldFrame(paleReturn,['KeyW']);
  const z=worldState(paleReturn);
  if(z.y<=8*16+.5){paleReturnAtTop=true;break;}
}
assert.equal(paleReturnAtTop,true,'Pale Burrow return vine is climbable');
worldFrame(paleReturn,['KeyW','KeyE'],['KeyE']);
let paleReturnDestination=null;
for(let i=0;i<30;i++){worldFrame(paleReturn,[]);const z=worldState(paleReturn);if(z.tr||z.room===4){paleReturnDestination=z.tr?z.tr.to:z.room;break}}
assert.equal(paleReturnDestination,4,'Pale Burrow hidden vine returns to Ossuary Stairs');
console.log('PASS: Pale Burrow has a climbable concealed return ladder');

// Direct render passes: room props must run in the available canvas context and avoid dependency assets.
const artCheck=makeRouteRoom(9,15*16+8,0);
vm.runInContext('draw();',artCheck);
assert.ok(source.includes('const widths=[6,14,21,27,33,38,42,45,48,50,51,51,51]'), 'lunar teleporter has a stepped Moon gate opening');
const benchCheck=makeRouteRoom(10,6*16+8,0);
vm.runInContext('draw();',benchCheck);
assert.ok(source.includes("tx('NO COST TOO GREAT.'"), 'Hollow Knight-inspired crypt has the small wall inscription');
console.log('PASS: lunar teleporter and seated-Knight bench artwork render without external assets');

// Major achievement milestones, plus flawless-run awards on final boss completion.
const achievementCheck=makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';fade=0;ban=null;",achievementCheck);
for(let room=1;room<=8;room++)vm.runInContext(`loadRoom(${room},88,239.99);`,achievementCheck);
assert.equal(read(achievementCheck,"Object.keys(S.ach).length"),0,'ordinary room visits do not award individual room achievements');
vm.runInContext('loadRoom(8,88,239.99);',achievementCheck);
assert.equal(read(achievementCheck,"Object.keys(S.ach).length"),0,'returning to a visited area does not award a room achievement');
vm.runInContext('loadRoom(9,88,239.99);loadRoom(10,88,239.99);',achievementCheck);
assert.equal(read(achievementCheck,'S.ach.secret_rain'),1,'entering Risk of Rainfall awards its secret discovery');
assert.equal(read(achievementCheck,'S.ach.secret_burrow'),1,'entering the Pale Burrow awards its secret discovery');
vm.runInContext("grab({k:'dash',x:40,y:100});grab({k:'mask',x:80,y:100});pull();",achievementCheck);
assert.equal(read(achievementCheck,'S.ach.dash_relic'),1,'recovering the dash relic earns a milestone');
assert.equal(read(achievementCheck,'S.ach.spare_mask'),1,'finding the spare mask earns a milestone');
assert.equal(read(achievementCheck,'S.ach.root_lever'),1,'opening the Chapel gate earns a milestone');
vm.runInContext("loadRoom(7,88,239.99);B.s='idle';B.hp=1;B.inv=0;dmgE(B,2,1);",achievementCheck);
assert.equal(read(achievementCheck,'S.ach.boss_bellkeeper'),1,'defeating the Bellkeeper awards the boss achievement');
assert.equal(read(achievementCheck,"Object.keys(S.ach).length"),8,'boss-room challenge awards remain distinct from the two full-demo completion awards');
assert.equal(JSON.parse(achievementCheck.__storage.last_apothecary_v1).ach.boss_bellkeeper,1,'achievement progress persists in the existing game save');
assert.equal(JSON.parse(achievementCheck.__storage.last_apothecary_achievements_v1).boss_bellkeeper,1,'achievement ledger is saved separately from a playthrough');
vm.runInContext('S=newS();',achievementCheck);
assert.equal(read(achievementCheck,"Object.keys(S.ach).length"),8,'starting a new game preserves lifetime achievement ledger entries');
assert.equal(read(achievementCheck,'S.run.hitless'),true,'a new game starts a fresh no-hit run');
assert.equal(read(achievementCheck,'S.run.deaths'),0,'a new game starts with zero deaths');
vm.runInContext("st='pause';pauseAction(2);draw();",achievementCheck);
assert.equal(read(achievementCheck,"st==='achievements'"),true,'the pause menu opens the achievement viewer');
assert.equal(read(achievementCheck,'achPage'),0,'the achievement viewer opens on its first page');
vm.runInContext("K={ArrowRight:1};PR={ArrowRight:1};menuStep();",achievementCheck);
assert.equal(read(achievementCheck,'achPage'),1,'Right arrow opens the second page of achievements');
vm.runInContext("K={ArrowLeft:1};PR={ArrowLeft:1};menuStep();",achievementCheck);
assert.equal(read(achievementCheck,'achPage'),0,'Left arrow returns to the first page of achievements');
vm.runInContext("K={Escape:1};PR={Escape:1};menuStep();",achievementCheck);
assert.equal(read(achievementCheck,"st==='pause'"),true,'the achievement viewer returns to the pause menu');
vm.runInContext('toTitle();',achievementCheck);
assert.equal(read(achievementCheck,"opts.includes('Achievements')"),true,'the title menu keeps achievements available between sessions');
const legacyAchievementSave=makeGameContext();
legacyAchievementSave.__storage.last_apothecary_v1=JSON.stringify({f:{},mhp:5,rg:0,seen:{},cp:{r:0,x:88,y:239.99}});
assert.deepEqual(Object.keys(read(legacyAchievementSave,'readSave().ach')),[],'older saves load with an empty achievement record instead of failing');
const discoveredLegacySave=makeGameContext();
discoveredLegacySave.__storage.last_apothecary_v1=JSON.stringify({f:{boss:1},mhp:5,rg:0,seen:{0:1,9:1},cp:{r:0,x:88,y:239.99}});
const restoredAchievements=read(discoveredLegacySave,'readSave().ach');
assert.equal(restoredAchievements.area_quarantine,undefined,'legacy per-room achievements are discarded from the simplified milestone list');
assert.equal(restoredAchievements.secret_rain,1,'older saves grant the discovery badge for a secret room already found');
assert.equal(restoredAchievements.boss_bellkeeper,1,'older saves grant the boss badge for an already completed fight');
assert.equal(read(achievementCheck, 'ACHIEVEMENTS.length'),10,'achievement catalogue contains six milestones, two boss-fight challenges, and two full-demo challenges');
assert.ok(source.includes("tx('ACHIEVEMENTS'") && source.includes('MAJOR MILESTONES') && source.includes('ACHIEVEMENTS.slice(achPage*5,(achPage+1)*5)') && source.includes("'Arial, Helvetica, sans-serif'"), 'achievement screen paginates ten milestones into five large, readable cards per page');

// Run challenge tracking: damage invalidates Untouchable, deaths count once, and both stats survive checkpoint respawns and saves.
const runTracking = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';p.hp=5;p.inv=0;hurtP(1,p.x+12,false);", runTracking);
assert.equal(read(runTracking,'S.run.hitless'),false,'taking actual damage breaks the no-hit run');
assert.equal(read(runTracking,'S.run.deaths'),0,'nonlethal damage does not count as a death');
assert.equal(JSON.parse(runTracking.__storage.last_apothecary_v1).run.hitless,false,'no-hit failure is persisted immediately');
vm.runInContext("p.hp=1;p.inv=0;p.st='n';hurtP(1,p.x+12,false);", runTracking);
assert.equal(read(runTracking,'S.run.deaths'),1,'a lethal hit increments the run death counter once');
vm.runInContext('respawn();', runTracking);
assert.equal(read(runTracking,'S.run.deaths'),1,'checkpoint respawn does not reset the run death counter');
assert.equal(read(runTracking,'S.run.hitless'),false,'checkpoint respawn does not restore no-hit eligibility');
vm.runInContext('loadRoom(6,88,239.99);', runTracking);
assert.equal(read(runTracking,'S.run.deaths'),1,'changing rooms does not reset the run death counter');
assert.equal(read(runTracking,'S.run.hitless'),false,'changing rooms does not restore no-hit eligibility');

const flawlessRun = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';loadRoom(7,88,239.99);B.s='idle';B.hp=1;B.inv=0;S.run.hitless=true;S.run.deaths=0;S.bossRun.hitless=true;S.bossRun.deaths=0;dmgE(B,2,1);", flawlessRun);
assert.equal(read(flawlessRun,'S.ach.untouched_run'),1,'a damage-free run earns Untouchable after defeating the Bellkeeper');
assert.equal(read(flawlessRun,'S.ach.deathless_run'),1,'a zero-death run earns One Life, One Cure after defeating the Bellkeeper');

const cleanButHitRun = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';loadRoom(7,88,239.99);B.s='idle';B.hp=1;B.inv=0;S.run.hitless=false;S.run.deaths=0;S.bossRun.hitless=false;S.bossRun.deaths=0;dmgE(B,2,1);", cleanButHitRun);
assert.equal(read(cleanButHitRun,'S.ach.untouched_run'),undefined,'taking damage prevents Untouchable');
assert.equal(read(cleanButHitRun,'S.ach.deathless_run'),1,'taking damage without dying still qualifies for One Life, One Cure');

const deathRun = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';loadRoom(7,88,239.99);B.s='idle';B.hp=1;B.inv=0;S.run.hitless=false;S.run.deaths=1;S.bossRun.hitless=false;S.bossRun.deaths=1;dmgE(B,2,1);", deathRun);
assert.equal(read(deathRun,'S.ach.untouched_run'),undefined,'a run with damage does not earn Untouchable');
assert.equal(read(deathRun,'S.ach.deathless_run'),undefined,'a run with a death does not earn One Life, One Cure');


const perfectDemo = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';S.f.boss=1;S.run.hitless=true;S.run.deaths=0;S.bossRun.hitless=false;S.bossRun.deaths=1;", perfectDemo);
assert.equal(read(perfectDemo,'S.ach.flawless_demo'),undefined,'full-demo flawless award is not granted before the ending');
assert.equal(read(perfectDemo,'S.ach.deathless_demo'),undefined,'full-demo deathless award is not granted before the ending');
vm.runInContext('endGame();',perfectDemo);
assert.equal(read(perfectDemo,'S.ach.flawless_demo'),1,'finishing the entire demo without HP damage earns Flawless Formula');
assert.equal(read(perfectDemo,'S.ach.deathless_demo'),1,'finishing the entire demo without deaths earns A Life Preserved');

const hitButAliveDemo = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';S.f.boss=1;S.run.hitless=false;S.run.deaths=0;endGame();",hitButAliveDemo);
assert.equal(read(hitButAliveDemo,'S.ach.flawless_demo'),undefined,'taking damage during the demo prevents Flawless Formula');
assert.equal(read(hitButAliveDemo,'S.ach.deathless_demo'),1,'taking damage without dying still earns the full-demo deathless award');

const diedDemo = makeGameContext();
vm.runInContext("S=newS();startPlay();st='play';S.f.boss=1;S.run.hitless=false;S.run.deaths=1;endGame();",diedDemo);
assert.equal(read(diedDemo,'S.ach.flawless_demo'),undefined,'a run containing damage cannot earn the full-demo flawless award');
assert.equal(read(diedDemo,'S.ach.deathless_demo'),undefined,'a run containing a death cannot earn the full-demo deathless award');
console.log('PASS: Flawless Formula and A Life Preserved unlock only on full demo completion with eligible run history');

const legacyRunSave = makeGameContext();
legacyRunSave.__storage.last_apothecary_v1=JSON.stringify({f:{},mhp:5,rg:0,seen:{},cp:{r:0,x:88,y:239.99}});
const migratedRun=read(legacyRunSave,'readSave().run');
assert.equal(migratedRun.hitless,false,'legacy saves with no run history cannot claim the no-hit achievement');
assert.equal(migratedRun.deaths,1,'legacy saves with no run history cannot claim the no-death achievement');
assert.equal(read(legacyRunSave,'readSave().bossRun.hitless'),false,'legacy saves without boss-fight history cannot retroactively claim the boss no-hit challenge');
assert.equal(read(legacyRunSave,'readSave().bossRun.deaths'),1,'legacy saves without boss-fight history cannot retroactively claim the boss deathless challenge');
console.log('PASS: Untouchable and One Life, One Cure require damage-free/death-free boss-fight conditions');

console.log('PASS: major-milestone achievements unlock once, persist, remain readable, and open from the menus');

console.log('NOTE: This is a recovery diagnostic suite, not the missing original regression/reachability suite.');
