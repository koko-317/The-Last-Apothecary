# Copy The Last Apothecary Final Demo to GitHub

The complete playable source is `index.html`. It includes the page structure, styles, all game JavaScript, level data, and procedural pixel-art rendering in one file.

## Option A — Publish the standalone game

1. Download `The Last Apothecary Final Demo.html` and open it in a code editor (VS Code, Notepad, or another text editor). Do not copy from the rendered game page.
2. Select all source text and copy it.
3. Create a GitHub repository.
4. In the repository, select **Add file → Create new file** and name it `index.html`.
5. Paste the source and commit it.
6. Open **Settings → Pages** and publish from the repository's branch/root directory.

## Option B — Add the full project and tests

1. Extract the project ZIP.
2. Upload all of its contents to the GitHub repository root, preserving folders like `tests/` and `ports/`.
3. Commit the files.
4. Run diagnostics locally with Node.js using `node tests/run.js`.
5. Publish `index.html` with GitHub Pages if desired.

The browser game itself has no dependency installation or build step. Node.js is needed only for running the diagnostic suite. The Unity and Unreal folders are source-only starter prototypes and have not been compiled in their respective editors.
