# The Last Apothecary Final Demo — Recovery Notes

## Current deliverable

The root `index.html` is the complete standalone HTML5 browser game. It includes inline CSS, JavaScript, level data, all pixel-art drawing code, and synthesized audio. Open the file directly in a modern desktop browser; no server, build process, external runtime asset, or npm dependency is required.

## Achievement tracking

The final catalog contains ten achievements:

- Six milestones: dash relic, Chapel gate, spare mask, each secret room, and the Bellkeeper.
- **Untouchable**: defeat the Bellkeeper without losing HP during the boss fight.
- **One Life, One Cure**: defeat the Bellkeeper without dying during the boss fight.
- **Flawless Formula**: complete the entire demo without taking damage.
- **A Life Preserved**: complete the entire demo without dying.

The previous `S.run` fields (`hitless` and `deaths`) track the whole New Game-to-ending run, surviving room transitions, checkpoints, and reloads. The two final-demo achievements unlock only when `endGame()` is reached after the Bellkeeper is defeated. A separate `S.bossRun` record tracks only damage/deaths inside Bellkeeper's Chamber, preserving distinct boss-specific challenges. Starting a new game resets run records but preserves the lifetime achievement ledger. Older saves without `bossRun` history are marked ineligible for the two boss-specific challenges rather than being granted those awards retroactively.

The ten achievement cards are presented as two pages of five larger rows to preserve readability on the fixed 480×272 canvas. Left/Right, A/D, or Page Up/Page Down changes pages; B/Esc returns to the prior screen.

## Validation

Run:

```sh
node tests/run.js
```

The test suite validates script syntax, movement/platform collision, sight/projectile blocking, progression flags, all room connections, actual input through `step(dt)`, the two boss-only challenges, the two whole-demo challenges, persistence, menu controls, and the known timing divergence. See `TEST_RESULTS.txt` for the exact passing output. Tests that isolate reachability disable enemies and may enable dash; they do not certify an uninterrupted combat playthrough.

## Known timing issue

A direct planner call to `updP()` bypasses hitstop in `step(dt)`. The supplied six-frame scenario produces planner-style x≈65.2633 px versus actual-loop x=36.93 px, a difference of approximately 28.3333 px. The original walkthrough planner was not available to patch. Future planner work should advance frames via `step(dt)` and preserve hitstop, held keys, pressed-key edges, transition state, and fade state instead of changing gameplay physics to hide the difference.

## Provenance and limitations

This is a best-effort reconstruction, not byte-for-byte recovery. The original `fix.html`, walkthrough planner, original regression tests, original reachability suite, and previously mentioned Unity files were not included in the recoverable files. The `tests/run.js` suite is a newly supplied recovery suite. Unity and Unreal starter source under `ports/` is uncompiled and does not implement every browser-game mechanic. No license has been chosen because the intended licensing terms and asset rights have not been confirmed.
