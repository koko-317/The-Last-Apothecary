# Room-by-Room Reachability Report — Final Demo

## Audit summary

- **11/11 authored rooms are reachable** from Sealed Chapel in the room graph while the optional high Chapel gate shortcut remains locked.
- **18/18 ordinary doorway spawn configurations** were checked for valid destination-room bounds and collisions with solid geometry.
- Door targets and reverse-door indices were checked for every authored exit.
- The focused traversal tests use real held-key/pressed-key inputs through `step(1/60)`, not direct teleports while completing the tested routes.
- Route-test hostiles/boss are disabled to isolate platforming geometry. Dash is enabled in the route harness; the Cistern route tests use it because that crossing is designed to require dash.

## Rooms and routes checked

The two optional Easter eggs are separate, concealed branches: **Risk of Rainfall** is entered by falling through a moss-veiled seam in Flooded Wards' first floor gap and returns through a low hidden hatch; **The Pale Burrow** is reached by climbing inconspicuous wall vines in Ossuary Stairs and pressing E at the upper seam, then returns via another hidden vine ladder at its far-right wall. Neither bonus room directly connects to the other or to Reliquary. The Reliquary (extra-health mask) is now a one-exit side room whose right-side return doorway has an explicitly solid, visible lintel above the opening.

| Room | Access / exit verification | Result |
|---|---|---|
| **Sealed Chapel** | Low exit to Plague Street works while the high gate remains locked. The high exit remains gated until the Root Hall lever flag is set. | Pass |
| **Plague Street** | Low exits tested in both directions with Cistern Gate; four-step one-way staircase reaches Apothecary Vault without needing the dash unlocked in advance. | Pass |
| **Cistern Gate** | Full entry-side pit crossing reaches Ossuary Stairs via actual `step()` frames with dash unlocked and enemies disabled. Return door to Plague Street tested. | Pass |
| **Apothecary Vault** | Reachable over Plague Street's staircase; normal jump reaches the solid shelf and collects the dash upgrade; low door returns to Plague Street. | Pass |
| **Ossuary Stairs** | Lower links to Cistern Gate and Root Hall tested. Upper staircase reaches Reliquary. A thin, disguised vine ladder at the inner wall branches to Pale Burrow; it is not a standard door. Entry and return are checked through the real `step()` loop. | Pass |
| **Root Hall** *(Rootbound Ossuary region)* | All three steps remain solid. A floor dip beneath columns 1–12 provides a safe under-stair passage. Tested left-to-right through to Flooded Wards and right-to-left under the staircase to the low Ossuary exit. Lever stairs are reachable and activate the high Chapel shortcut. | Pass |
| **Flooded Wards** | Left exit returns to Root Hall. Both floor gaps can be crossed with jumps, then the lower-right exit reaches Bellkeeper's Chamber. The first gap includes a moss-veiled hidden drop into Risk of Rainfall; the fall transition is tested through `step()`. The second gap is now bridged by a weathered one-way plank across the pit; the formerly disconnected stairs beyond it were removed. The bridge can be reached by jumping from the approach side, then the player can step down to the floor and continue into Bellkeeper's Chamber. | Pass |
| **Bellkeeper's Chamber** | Reached from Flooded Wards and its return exit back to Flooded Wards is tested. Enemies/boss are disabled for the route test. | Pass |
| **Reliquary** | Reached from Ossuary via the high staircase; solid shelf is jumpable and the right-side exit returns to Ossuary. Its right wall tile directly above the doorway is explicitly solid and rendered as a stone lintel; the doorway remains open below it. | Pass |
| **Risk of Rainfall** *(Risk of Rain Easter egg)* | Separate branch reached by falling through the moss-covered seam in Flooded Wards. A low hatch returns to Flooded Wards. Both entry and return are checked through the actual `step()` loop. The room draws a custom stepped stone Moon gate, lunar terrain, distant Commencement/Mithrix citadel, and inset control in procedural pixel art. The gate is ground-anchored and scaled to the character/world rather than displaying the reference screenshot. | Pass |
| **The Pale Burrow** *(Hollow Knight Easter egg)* | Separate hidden branch reached by climbing thin vines at an interior wall in Ossuary Stairs and pressing E at the upper seam. A second hidden vine ladder returns from the far-right wall. Entry and return are tested through the actual `step()` loop. The room uses a custom procedural slate-blue cavern and a smaller seated horned Knight on a carved checkpoint bench. The bench group is scaled around its floor anchor so the Knight, bench, and nearby lantern are integrated into the playable scene; no screenshot is stretched or cropped across the viewport. | Pass |

## Root Hall pathing detail

The Root Hall steps remain ordinary solid platforms; one-way platforms were not used as a blanket fix. In the current room grid, columns 1–12 at row 15 are clear, row 16 remains the safe lower floor, and column 0 at row 15 remains solid as the left jump-out ledge. This creates a route below all three stair sections, then lets the player jump back to the low Ossuary doorway height. The previous Root Dip overlay instruction has been removed from the in-game text. The lever hint remains; the alternate passage is now explained by its geometry rather than a text prompt.

## Boss arena boundary check

The Bellkeeper's horizontal charge is clamped to the arena between one tile from either side wall plus half the boss width. If a charge reaches either bound, it stops and enters its stun state. The new diagnostics exercise the left and right boundaries and check that the complete boss body remains on-screen.

## Credits and Easter egg additions

The title menu includes a Credits screen crediting John Kokoska for game design and development. The Risk of Rain reference is an original “Risk of Rainfall” room with a block-stepped Moon gate, lunar terrain, the distant Mithrix/Commencement citadel, an inset field console, and storm/rain backdrop. The Hollow Knight reference is an original “The Pale Burrow” room with a Knight-like horned sprite seated on its checkpoint bench, muted slate cave palette, lantern, and the inscription “NO COST TOO GREAT.” Their entrances are deliberately disguised as a moss-veiled fall and a wall vine ladder respectively, and their connectors stay hidden on the map until both endpoints are visited. The two user-provided reference images informed the composition and palette only; the shipped game draws its Easter egg scenes procedurally, so there are no full-screen image overlays, image crops, external asset files, or image network requests. Real-loop route tests confirm both entry and return paths.

## Timing diagnostic retained

The supplied six-frame state still shows the known approximately **28.33 px** divergence between a planner calling `updP()` and the real `step(dt)` loop. `step(dt)` pauses player motion while hitstop is positive, whereas direct `updP()` does not. This audit documents but does not hide the mismatch by changing movement physics. A future planner must advance via `step(dt)` and preserve hitstop, held/pressed input state, transitions, and fade state.

## Limits of this report

This is a recovered/new diagnostic suite, **not** the unavailable original reachability suite. It does not certify an uninterrupted unassisted full playthrough or combat balance. The `fix.html`, original planner, regression suite, reachability suite, and prior Unity source were unavailable. Unity and Unreal folders remain source-only starter projects; they were not compiled in their native engines.

## Achievement catalogue/readability update

The achievement ledger contains ten meaningful achievements: six progression milestones, two boss-fight challenges (Untouchable and One Life, One Cure), and two full-demo completion challenges (Flawless Formula and A Life Preserved). Ordinary room visits do not award individual room achievements. Full-run stats persist through room changes, checkpoint respawns, and saves; starting New Game resets run stats but preserves lifetime achievement unlocks. Legacy saves without reliable boss-fight history cannot retroactively claim the boss-only awards. The achievement screen uses two pages of five large, high-contrast cards.


## Final Demo full-playthrough achievements

- **Flawless Formula** unlocks only on the ending after the Bellkeeper is defeated if the entire New Game run recorded no actual HP damage.
- **A Life Preserved** unlocks only on the ending after the Bellkeeper is defeated if the entire New Game run recorded zero deaths. Taking damage is allowed for this award.
- **Untouchable** and **One Life, One Cure** now track the boss encounter separately, so these two boss-fight awards are distinct from the whole-demo challenges.
- The achievement screen uses two pages of five large, high-contrast cards. Change pages with Left/Right, A/D, or Page Up/Page Down.
