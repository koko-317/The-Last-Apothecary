# Running the browser game on Replit

The game is a self-contained HTML page. The configured Replit workflow serves the project root with Python's built-in HTTP server; no package install or build step is needed.

- Start the **Start application** workflow to open the game preview.
- Run the regression and route checks with `node tests/run.js`.
- Achievement progress is saved alongside the existing game save in browser storage. Achievements are available from the title and pause menus, or by pressing **B** during play.
